"""
This module looks for a tweets.csv file in the path, detects coin names and tickers regex, translate tweets and gets semantic of the sentence.
Asks all these tweets to an LLM to analyze semantically/ summarize (gemini 1.5 pro support this context window for free but another cheaper approach can be asking only the caught tweets).
If will used daily, 30 influencer's last 10 tweets can be pulled with X API v2 basic (100 dollars per month).
"""

import os
import pandas as pd
import requests
import datetime
import utils
from dotenv import load_dotenv
from transformers import pipeline, TextClassificationPipeline, AutoModelForSequenceClassification, AutoTokenizer
from langchain_openai import ChatOpenAI
from langchain_openai import AzureOpenAI
from langchain_groq import ChatGroq
from langchain_google_genai import ChatGoogleGenerativeAI
from youtube_transcript_api import YouTubeTranscriptApi
from langchain_core.messages import HumanMessage
from googleapiclient.discovery import build
from tqdm import tqdm
import langdetect
import torch
import re
import time
import traceback
import x_client
from bs4 import BeautifulSoup
import json
import locale


COIN_DICT_LAST_UPDATE_DATE = datetime.datetime.now() - datetime.timedelta(hours=0)
COIN_DICT = utils.COIN_DICT

device = 0 if torch.cuda.is_available() else -1
print(f"Running with device: {device}")

tokenizer = AutoTokenizer.from_pretrained("ElKulako/cryptobert", use_fast=True)
model = AutoModelForSequenceClassification.from_pretrained("ElKulako/cryptobert", num_labels = 3)
crypto_semantic_pipe = TextClassificationPipeline(model=model, tokenizer=tokenizer, max_length=64, truncation=True, padding = 'max_length')

translation_pipeline = pipeline("translation", model="Helsinki-NLP/opus-mt-tc-big-tr-en", device=device)

def get_trend_topics(language:str, count=2):
    locale.setlocale(locale.LC_TIME, 'en_US.UTF-8')
    current_day = datetime.datetime.now().strftime('%A')
    
    if 'EN' in language:
        country = "united-states"
        day_of_the_week = current_day.lower()
    elif 'TR' in language:
        country = "turkey"
        turkish_days = {
            'Monday': 'pazartesi',
            'Tuesday': 'salı',
            'Wednesday': 'çarşamba',
            'Thursday': 'perşembe',
            'Friday': 'cuma',
            'Saturday': 'cumartesi',
            'Sunday': 'pazar'
        }
        day_of_the_week = turkish_days[current_day]

    url = f"https://trends24.in/{country}/index.html"
    headers = {
        "Accept": "text/html,/*; q=0.01",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "en-US,en;q=0.5",
        "Priority": "u=1, i",
        "Referer": url,
        "Sec-CH-UA": '"Brave";v="129", "Not=A?Brand";v="8", "Chromium";v="129"',
        "Sec-CH-UA-Mobile": "?0",
        "Sec-CH-UA-Platform": '"Linux"',
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "Sec-GPC": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
        "X-Requested-With": "XMLHttpRequest"
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        print("Trends are downloaded.")
        response.encoding = 'utf-8'

        # Parse the HTML content with BeautifulSoup
        soup = BeautifulSoup(response.text, 'html.parser')

        # Find the first trend list containing the trending topics
        topics_list = soup.find('ol', class_='trend-card__list')  # Adjust based on actual HTML structure
        
        if topics_list:
            # Use a set to store topics and eliminate duplicates
            topics = set()
            for topic in topics_list.find_all('li'):  # Get the first 5 list items
                trending_topic = topic.find('a').text  # Extract the topic name
                topics.add(trending_topic)

            # Join the unique topics with a space and format them with a hashtag symbol
            topic_list = [f"{topic}" for topic in topics]
            trending_string = ', '.join(topic_list)

            print(trending_string)
            
            llm =_get_llm(model_name="llama3")
            
            prompt = f"""
            Your mission is returning the finance, crypto, investment, economy, money related trend topics.
            The context is, you are receiving trend topics for that day, and your job is returning only the the finance, crypto, investment, economy, money related trend topics by working like a filter.
            Do NOT say anything, just filter accordingly.
            If you found nothing return None.
            Do NOT add a trend topic that is not given to you.
            You can look for these types of words in the input: crypto, coin, tl, finance, investment, economy, money, rich, poor, money, $btc, gold, cash, stocks, wealth, assets, capital, inflation, recession, banking, trading, forex, currency, dividends, bonds, equity, profit, loss, hedge, portfolio, taxes, income, markets, loans, savings, commodities, real estate, entrepreneurship, ROI, venture capital, fundraising, liquidity, speculation, bull market, bear market, $eth, $ltc, silver, debt, credit, leverage, futures, IPO, interest rates, financial freedom, wealth management, hedge funds, fintech, volatility, blockchain, yield, net worth.
            You can also look for these coin tickers in the input: {COIN_DICT}

            <Examples>:
            <Example 1>:
            <Human>:
            Credit, #Saturday, Finance, Mehmet Simsek, #27OctoberWeHaveARally, Extortion, Turkey - Montenegro, Ambulance Murder, gold, Montella, Sunday, November 17, Dursun Ozbek, #stock marketrobbery, #gebzmayorresignation, #taxcancellation, Defense, #tax, $btc
            <AI>:
            Finance, Mehmet Simsek, gold, #stock marketrobbery, #taxcancellation, #tax, Credit, $btc

            Example 2:
            <Human>:
            Bertug, Deli Dumrul, Mehmet Agar, President Erdogan
            <AI>:
            None

            Examples finished. Now it's your turn, only filter finance related ones do not say anything else for these input:
            """
            # Get the trending topics string from the LLM
            trending_string = _get_answer_from_llm(llm=llm, prompt=prompt, context=trending_string)

            # Split the string into a list, strip whitespace, and limit to the specified count
            trending_list = [item.strip() for item in trending_string.split(",")][:count]

            # Join the list back into a string, separated by commas
            trending_string = ', '.join(trending_list)
            if "None" in trending_string:
                trending_string = f"{topic_list[0]}" # if none of them are about finance, add the most popular trend topic
            trending_string += f" #{day_of_the_week}" # and the day of the week
            print(f"Trend topics: {trending_string}")
            return trending_string
    else:
        print(f"Failed crawling. Error: {response.status_code}")
        return ""


def check_new_ath() -> tuple[dict[str, dict[int, str]], dict[str, dict[int, str]]]:
    json_path = "coin_ath.json"

    # Check if the JSON file exists
    if not os.path.exists(json_path):
        return {"error": "JSON file does not exist."}, {}

    # Safely load existing prices from the local JSON file
    try:
        with open(json_path, 'r') as file:
            coin_data = json.load(file)
            if not isinstance(coin_data, dict):
                raise ValueError("JSON file must contain a dictionary.")
    except (json.JSONDecodeError, ValueError) as e:
        return {"error": f"Failed to load JSON file: {e}"}, {}

    # Get the latest price of Bitcoin and Ethereum from CoinGecko API
    coingecko_url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd"
    try:
        response = requests.get(coingecko_url, timeout=10)
        response.raise_for_status()  # Raise an HTTPError for bad responses (4xx, 5xx)
        latest_prices = response.json()
        bitcoin_price_now = latest_prices['bitcoin']['usd']
        ethereum_price_now = latest_prices['ethereum']['usd']
    except (requests.RequestException, KeyError, ValueError) as e:
        return {"error": f"Failed to fetch data from CoinGecko API: {e}"}, {}

    # Function to update the price if a new ATH is reached or if the price drops 50% or more below the old price
    def update_coin_ath(coin_name: str, current_price: float) -> dict[str, dict[int, str]]:
        nonlocal coin_data  # Reuse the loaded JSON data

        # Ensure the price is a valid number
        if not isinstance(current_price, (int, float)) or current_price <= 0:
            return {"error": f"Invalid price for {coin_name}: {current_price}"}

        if coin_name in coin_data:
            try:
                old_price = float(coin_data[coin_name])  # Ensure the old price is numeric
            except (TypeError, ValueError):
                return {"error": f"Invalid old price in JSON for {coin_name}."}

            # Check if the current price is 50% or less of the old price
            if current_price <= 0.5 * old_price:
                coin_data[coin_name] = current_price
                with open(json_path, 'w') as file:
                    json.dump(coin_data, file, indent=4)
                return {"update": f"Replaced {coin_name} ATH with ${current_price:,.2f} as it's 50% or less of the old ATH."}

            # Calculate threshold as 10% above the old ATH
            threshold = old_price * 1.1
            # If the current price exceeds the threshold, update the ATH
            if current_price >= threshold:
                new_ath = round(current_price / 10) * 10
                coin_data[coin_name] = new_ath
                with open(json_path, 'w') as file:
                    json.dump(coin_data, file, indent=4)
                return {coin_name: new_ath}

            return {"info": f"{coin_name} price is ${current_price:,.2f}, but hasn't broken the threshold of ${threshold:,.2f}."}
        else:
            return {"error": f"{coin_name} data not found in JSON file."}

    # Check and update ATH for Bitcoin and Ethereum
    btc_dict = update_coin_ath(coin_name='Bitcoin', current_price=bitcoin_price_now)
    eth_dict = update_coin_ath(coin_name='Ethereum', current_price=ethereum_price_now)

    # Combine and return the results
    return btc_dict, eth_dict


def analyze_single_tweet(tweet_url: str, language:str, consumer_key: str, consumer_secret: str, access_token: str, access_secret: str, bearer_token: str) -> tuple[str, int]:
    # Step 1: Extract username and tweet ID from the tweet URL
    tweet_id, username = _extract_tweet_info(tweet_url)
    
    if not tweet_id or not username:
        return "FAIL: Invalid tweet URL", 400

    # Step 2: Get tweet content using the username and tweet ID
    tweet_content = _get_tweet_content(tweet_id=tweet_id, username=username, bearer_token=bearer_token)

    if not tweet_content:
        return "FAIL: Unable to fetch tweet content. Check URL or permissions.", 400

    prompt = f"""
    You're an experienced bitcoin market analyst.
    You will be provided with a tweet that contains news or analysis.

    Task:
    You must examine this news, fact, or opinion in terms of its impact on the cryptocurrency market, including the indicating term.

    Format:
    Act like an analyst.
    If someone has an opinion, appreciate it but don't be too definite because everything should be considered possible.
    Agree with reasonable viewpoints, such as yes and I believe so. Write potentially incorrect opinions in the form of queries such as, "Can't it be this way?"
    Trying not to offend the tweeter while expressing our opinion.

    
    Language:
    Your response must be in {language} language and suitable for tweeting.
    Use a neutral, analytical tone that is professional but accessible.
    
    <Example>:
    <HUMAN>:
    The US Core Personal Consumption Expenditure Price Index (PCE) was announced as 2.7 annually. Expected 2.7, previous 2.6.

    <AI>:
    The US Core Personal Consumption Expenditure Price Index (PCE) was announced as 2.7% annually, which is in line with expectations.
    However, the previous data was 2.6%, which indicates a slight increase.
    This situation shows that inflationary pressures in the US continue to some extent.
    In the short term, crypto markets may react limitedly to this data.
    However, if inflationary risks continue in the medium term, investors may increase their interest in risky assets.
    The Fed's influence on interest rate policy is also an important factor. Rising interest rates could put pressure on crypto assets.

    The example is finished. Now it's your turn. Please provide the analysis in {language} language according to the following input:
    """
    llm = _get_llm("google")

    if len(tweet_content) > 10:
        # Step 3: Get the answer from LLM based on the tweet content
        answer = _get_answer_from_llm(llm=llm, prompt=prompt, context=tweet_content)
        final_answer = answer.replace("**", "")
        
        post_response = x_client.post(consumer_key=consumer_key, consumer_secret=consumer_secret, access_token=access_token, access_secret=access_secret, text=final_answer, post_id=tweet_id, is_premium=True)
        if post_response:
            return f"SUCCESS: {final_answer}", 200
        else:
            return "FAIL: Could not post the comment.", 400

    return "FAIL: Tweet content is too short or invalid.", 400


def _extract_tweet_info(tweet_url: str) -> tuple:
    try:
        # Assumes standard tweet URL format: https://x.com/{username}/status/{tweet_id}
        parts = tweet_url.split("/")
        tweet_id = parts[-1]
        username = parts[-3]
        return tweet_id, username
    except IndexError:
        return None, None

def _get_tweet_content(tweet_id: str, username: str, bearer_token: str) -> str:
    headers = {"Authorization": f"Bearer {bearer_token}"}
    url = f"https://api.twitter.com/2/tweets/{tweet_id}"
    params = {
        "tweet.fields": "text"
    }
    try:
        response = requests.get(url, headers=headers, params=params)
        if response.status_code == 200:
            return response.json().get("data", {}).get("text", "")
        else:
            print(f"Error fetching tweet: {response.status_code}, {response.text}")
            return ""
    except Exception as e:
        print(f"Error occurred while fetching tweet content: {e}")
        return ""


def _get_coin_dict() -> dict:
    """Gets coin dictionary that has coin ticker: coin name. When called it checks if it has been x days."""
    print("Getting the coin list...")
    global COIN_DICT_LAST_UPDATE_DATE, COIN_DICT
    current_time = datetime.datetime.now()
    time_difference = current_time - COIN_DICT_LAST_UPDATE_DATE
    if time_difference.total_seconds() >= 24 * 60 * 60 * 7:  # 7 day
        coin_dict = _update_coin_dict()
        COIN_DICT = coin_dict
        COIN_DICT_LAST_UPDATE_DATE = current_time
    else:
        coin_dict = COIN_DICT
    return coin_dict


def _load_tweets(file_path: str) -> pd.DataFrame:
    """Loads tweets."""
    print("Getting tweets...")
    tweets = pd.read_csv(file_path)
    return tweets


def _translate_tweets(tweets: pd.DataFrame) -> pd.DataFrame:
    """Translate tweets so crypto semantic analyze can be done.""" 
    print("Translating tweets...")   
    translated_tweets = []
    for _, row in tqdm(tweets.iterrows(), total=tweets.shape[0], desc="Translating"):
        text = row['text']
        if not text or len(text)< 5 or not any(char.isalpha() for char in text):
            print(f"Warning: tweet has no length text: {len(text)} {text}")
            continue
        try:
            if langdetect.detect(text) != 'en':
                translated_text = translate_to_english(text)[0]['translation_text']
            else:
                translated_text = text  
        except Exception as e:
            print(f"Warning translating tweet: {e} for this text: {text}")
            continue
        
        translated_tweets.append({
            'account': row['account'],
            'user': row['user'],
            'text': row['text'],
            'en_text': translated_text,
            'url': row['url'],
        })
    return pd.DataFrame(translated_tweets)
    

def translate_to_english(text: str) -> str:
    """Translating sentences to English from Turkish."""
    translated_text = translation_pipeline(text)
    return translated_text


def _update_coin_dict() -> dict:
    """Getting the top 120 coin ticker: name format. """
    print("It's been 24 hours since the last update. The coin list is getting updated...")
    url = 'https://api.coingecko.com/api/v3/coins/markets'
    params = {
        'vs_currency': 'usd',
        'order': 'market_cap_desc',
        'per_page': 500,
        'page': 1,
        'sparkline': False,
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        data = response.json()
        coin_dict = {}
        for coin in data:
            coin_dict[coin['symbol'].upper()] = coin['name']
        return coin_dict
    else:
        print(f"Failed to fetch data. Status code: {response.status_code}")
        return None


def _analyze_tweets(translated_tweets: pd.DataFrame, coin_dict:dict) -> pd.DataFrame:
    """For each translated tweet, it will find coins in sentence using regex and will do sentiment analysis of that sentence."""
    print("Analyzing tweets...")
    processed_data = []
    for _, row in translated_tweets.iterrows():
        sentence = row['en_text']
        original_sentence = row['text']
        url = row['url']
        coins = _find_coins_in_sentence(original_sentence, coin_dict)
        if coins:
            sentiment = _analyze_sentiment(sentence)
            processed_data.append({
                'account': row['account'],
                'user': row['user'],
                'original_sentence': original_sentence,
                'en_sentence': sentence,
                'coins': coins,
                'sentiment': sentiment,
                'url': url
            })
    return pd.DataFrame(processed_data)


def _find_coins_in_sentence(sentence: str, coin_dict: dict) -> list:
    """Coin names and tickers are search with RegEx and found coins list will returned."""
    found_coins = []
    sentence_lower = sentence.lower()
    
    # match coin names and tickers that are preceded or followed by non-alphabetical characters or whitespace (also do not match link if it has https in the next 5 chars)
    pattern = '|'.join([
        f'(?<![a-zA-Z])(?:{re.escape(ticker.lower())}|{re.escape(name.lower())})(?![a-zA-Z])'
        for ticker, name in coin_dict.items()
    ])
    regex = re.compile(pattern)
    
    # Find all matches in the sentence
    matches = regex.findall(sentence_lower)
    
    # Collect unique coin names based on matches
    for ticker, name in coin_dict.items():
        if any(match == ticker.lower() or match == name.lower() for match in matches):
            found_coins.append(name)
    
    return found_coins


def _analyze_sentiment(sentence: str) -> str:
    results = crypto_semantic_pipe(sentence)
    return results[0]['label']


def _get_llm(model_name:str):
    "Return one of the LangChain LLM's according to the model_name. OpenAI, AzureOpenAI, llama-3 and Gemini-pro is supported."
    try:
        load_dotenv()
        if model_name == "openai":
            OPENAI_KEY = os.getenv("OPENAI_KEY")
            llm = ChatOpenAI(model="gpt-4o",temperature=0,max_tokens=None,timeout=None,max_retries=2,api_key=OPENAI_KEY)
        elif model_name == "azure_openai":
            AZURE_AD_TOKEN = os.getenv("AZURE_AD_TOKEN")
            AZURE_AD_TOKEN_PROVIDER = os.getenv("AZURE_AD_TOKEN_PROVIDER")
            AZURE_DEPLOYMENT = os.getenv("AZURE_DEPLOYMENT")
            AZURE_ENDPOINT = os.getenv("AZURE_ENDPOINT")
            llm = AzureOpenAI(azure_ad_token=AZURE_AD_TOKEN, azure_ad_token_provider=AZURE_AD_TOKEN_PROVIDER, azure_deployment=AZURE_DEPLOYMENT, azure_endpoint=AZURE_ENDPOINT, model="gpt-3.5-turbo-instruct", temperature=0,)
        elif model_name == "llama3.1":
            GROQ_API_KEY = os.getenv("GROQ_API_KEY")
            llm = ChatGroq(api_key=GROQ_API_KEY, model_name="llama-3.1-70b-versatile", temperature=0)
        elif model_name == "llama3":
            GROQ_API_KEY = os.getenv("GROQ_API_KEY")
            llm = ChatGroq(api_key=GROQ_API_KEY, model_name="llama3-70b-8192", temperature=0)
        elif model_name == "llama3-small":
            GROQ_API_KEY = os.getenv("GROQ_API_KEY")
            llm = ChatGroq(api_key=GROQ_API_KEY, model_name="llama3-8b-8192", temperature=0)
        elif model_name == "Gemma2-9b":
            GROQ_API_KEY = os.getenv("GROQ_API_KEY")
            llm = ChatGroq(api_key=GROQ_API_KEY, model_name="Gemma2-9b-It", temperature=0)
        elif model_name == "llama-3.2-11b-v":
            GROQ_API_KEY = os.getenv("GROQ_API_KEY")
            llm = ChatGroq(api_key=GROQ_API_KEY, model_name="llama-3.2-11b-vision-preview", temperature=0)
        else:
            GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
            llm = ChatGoogleGenerativeAI(google_api_key=GOOGLE_API_KEY, model="gemini-1.5-pro", temperature=0)
        return llm
    except Exception as e:
        print(f"Error getting LLM: {e}")
        return None


def _get_tweet_summary_from_llm(language:str, llm, signal:str) -> str:
    """Asking LLM to summarize tweets."""
    print("Asking to llm...")
    prompt = f"""
    You are an experienced cryptocurrency trader and analyst specializing in the semantic analysis of crypto influencers.
    You will be presented with a table containing multiple cryptocurrency influencers' Twitter/X accounts and their posts.

    Task:
    Start by naming all crypto influencers name that you will summarize.
    Summarize the overall sentiment and key insights from each account's recent tweets.
    For each influencer, specify the coins mentioned (with their ticker and dolar sign like this: $BTC), describe how they are discussed, and highlight the most relevant details regarding the current state of the coin market.
    Number influencers with emoji numbers.
    Your response should be concise, professional, and easy to understand, avoiding unnecessary technical jargon unless it adds value.
    Divide each part with "----------" symbols so they can be seperated and tweeted individually.
    You don't need to talk about things that are not related to crypto, finance, or economics.

    Format:
    Account Overview: Summarize the influencer's general sentiment and focus.
    Give detailed answers, for example instead of saying "criticized the SEC's treatment of NFTs as securities", explain the details like "criticized it positively and stated that this development "prepares the market for the arrival of the bull".
    Coin Mentions: List the coins discussed, along with how they are described.
    Market Insights: Highlight key points related to the current market situation.
    Do not forget to say FLOOD at the beginning.
    
    Language:
    Your response must be in {language} language and suitable for tweeting.
    Use a neutral, analytical tone that is professional but accessible.
    
    <Example>:
    <HUMAN>:
    account user text
    CryptoKemal @CryptoKemal Call for solana degens;\nDont fade / $NST ! \nBest gem play for long term.\n-8.6m Sup\n-25 ppl legit team \n-Only 30M cap (multichain ETH,ARB,SOL)\n-2 Trading software 1 education more than 50K users\n(\n@ninjatoolsio\n & beta.ninjatools io)\n-Huge NFT community with 4k volume on opensea.
    bucoinedir @bucoinedir In a video I published on the channel yesterday (#altcoins), I said that the main reason for the decline was "exchanges and market makers". \n\nThere were those who said the FED caused it. \n\nThe Fed has had negative data for a long time. It is impossible for it to cause such declines. More importantly, these declines are FED
    <AI>:
    Below is a summary of the information shared yesterday by crypto influencers bucoinedir and CryptoKemal, the cryptocurrencies they mentioned, and general sentiments.

    FLOOD
    ----------
    \n 1/3 \n
    1️⃣ @bucoinedir:
    - General Sentiment: Critical, Neutral or Condescending
    - Cryptocurrencies: Altcoins, $BTC
    - Market Views: In the video he published on his channel yesterday, he stated that the main reason for the decline was stock exchanges and market makers. He stated that the declines could not be caused by the FED because the FED's negative data had been around for a long time and it was impossible for it to cause such big declines.
    ----------
    \n 2/3 \n
    2️⃣ @CryptoKemal:
    - General Sentiment: Positive, Concerned and Cautious
    - Cryptocurrencies: $SOL, $BTC
    - Market Views: He sees Solana as a long-term investment opportunity. He says that Bitcoin's price levels are critical and that short-term declines are expected in the market.
    ----------
    General Assessment:
    While Solana is seen as a long-term investment opportunity, it is emphasized that Bitcoin's price levels are critical and that short-term declines are expected in the market. It is stated that the main reason for these declines is stock exchanges and market makers, and that it is impossible for the FED's negative data to cause such large declines since it has been around for a long time.
    ----------
    
    The example is finished. Now it's your turn. Please provide the summary in {language} language according to the following input:
    """
    final_answer = _get_answer_from_llm(llm=llm, prompt=prompt, context=signal)

    return final_answer.replace("**","")

def _get_answer_from_llm(llm, prompt: str, context: str = "", media:str = "", retries: int = 4, max_delay: int = 300) -> str:
    """
    Asking LLM to summarize tweets. If it fails, retry with exponential backoff.
    The maximum delay between retries is capped at 5 minutes.
    If the delay exceeds the maximum, the function stops retrying.
    """
    print("Asking LLM to summarize tweets...")

    input = None
    if media:
        message = HumanMessage(
            content=[
                {"type": "text", "text": prompt},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{media}"},
                },
            ],
        )
        input = [message]
    else:
        date = f"<date_of_today>: {datetime.date.today()}"
        input = prompt + date + context

    delay = 10  # Initial delay in seconds

    for attempt in range(retries):
        try:
            final_answer = llm.invoke(input)
            return final_answer.content
        except Exception as e:
            print(f"Attempt {attempt + 1} failed with error: {e}. Retrying in {delay} seconds...")

            # Check if the delay exceeds the max delay, if so, break the loop
            if delay >= max_delay:
                print(f"Delay reached the maximum cap of {max_delay} seconds. Stopping further retries.")
                break

            time.sleep(delay)
            delay *= 2  # Exponentially increase the wait time

    # If all attempts fail, log an error and return None
    print("All models failed to provide an answer.")
    return None


def _summarize_operation(language:str, tweet_analysis_result: pd.DataFrame, tweets: pd.DataFrame) -> str:
    """The whole crypto influencer analysis operation is summarized by indicating total influencers, grouping coins and showing who talked about what in what manner."""

    if 'EN' == language:
        sentiment_translation = {
            'Neutral': 'Neutral ➡',
            'Bearish': 'Negative📉',
            'Bullish': 'Positive📈'
        }
        talked_by = "talked by:"
        most_popular_view= "and the most popular view is"
        influencer= "influencer's"
        scanned_tweets="tweets are scanned."
    elif 'TR' == language:
        sentiment_translation = {
            'Neutral': 'Nötr ➡',
            'Bearish': 'Negatif📉',
            'Bullish': 'Pozitif📈'
        }
        talked_by = "şu hesaplar tarafından konuşuldu: "
        most_popular_view= "ve en popüler görüş"
        influencer= "fenomenin"
        scanned_tweets="tweet'ini taradım."
    
    
    # Total Influencer Count
    total_influencers = tweets['user'].nunique()

    if total_influencers == 0:
        return "No match exists. A bug might happen in tweet retrieving or regex that finds coin names."

    # Grouping by Coin
    coin_data = tweet_analysis_result.explode('coins')
    coin_groups = coin_data.groupby('coins').agg({
        'user': lambda x: set(x),
        'sentiment': lambda x: x.value_counts().to_dict()
    })


    coin_hashtag_list = []
    coin_summary = []

    for coin, row in coin_groups.iterrows():
        # Join user names into a comma-separated string
        users = ', '.join(row['user'])
        
        # Calculate total sentiments
        total_sentiments = sum(row['sentiment'].values())
        # Calculate sentiment percentages and round to one decimal place
        sentiment_percentages = {
            sentiment_translation.get(sentiment, sentiment): round(count / total_sentiments * 100, 1)
            for sentiment, count in row['sentiment'].items()
        }
        # Find the highest percentage
        highest_percentage = max(sentiment_percentages.values())
        # Find all sentiments that have the highest percentage
        highest_sentiments = [sentiment for sentiment, percentage in sentiment_percentages.items() if percentage == highest_percentage]
        # Create a formatted string of the highest sentiments
        highest_sentiments_str = ', '.join([f"%{highest_percentage} {sentiment}" for sentiment in highest_sentiments])
        # Append the summary to coin_summary
        coin_summary.append(
            f"* ${coin} {talked_by} {users} {most_popular_view} {highest_sentiments_str}.\n"
        )

    # Total Tweet Count
    total_tweets = tweets.shape[0]

    # Generating the statistics sentences
    coin_summary_sentences = '\n'.join(coin_summary)
    total_influencers_sentence = f"{total_influencers} {influencer} "
    total_tweets_sentence = f"{total_tweets} {scanned_tweets}"

    # Combining all sentences with proper newlines
    final_summary = f"\n\n{total_influencers_sentence} {total_tweets_sentence}\n\n{coin_summary_sentences}\n\n"

    return final_summary



def influencer_analyser(language:str, coin_count:int, file_path:str = 'tweets.csv') -> tuple[str, str]:
    """
    The main function of influencer analyser that is public.
    It gets coin dictionary, loads tweets from path, asks llm to analyze all the tweets, caught coin names with regex, translate tweets and gets semantics, and summarize the all analysis operation.
    """

    coin_dict = _get_coin_dict()
    
    # Limiting by coin_count in marketcap order decreasing
    coin_dict_items = list(coin_dict.items()) # Convert the dictionary to a list of tuples (key-value pairs)
    limited_coin_dict_items = coin_dict_items[:coin_count] # Slice the list to get the first `coin_count` items
    coin_dict = dict(limited_coin_dict_items) # Convert the sliced list back into a dictionary
    
    tweets = _load_tweets(file_path=file_path)
    
    translated_tweets = _translate_tweets(tweets=tweets)
    tweet_analysis_result = _analyze_tweets(translated_tweets=translated_tweets, coin_dict=coin_dict)

    if tweet_analysis_result.empty:
        print(f"No posts found.")
        return "No coins are detected.", "Operation failed."

    tweet_analysis_result.to_csv("analysed_tweets.csv", index=False)

    operation = _summarize_operation(language=language, tweet_analysis_result=tweet_analysis_result, tweets=tweets)

    tweets_str = tweets.to_string(index=False)
    llm = _get_llm("google")
    llm_summary = _get_tweet_summary_from_llm(language=language, llm=llm, signal=tweets_str)
  
    return llm_summary, operation

def youtuber_analyser(language: str, youtube_influencers: list[str]) -> str:
    load_dotenv()
    YOUTUBE_API_KEY = os.getenv("YOUTUBE_API_KEY")

    video_urls = []
    for influencer in youtube_influencers:
        try:
            video_urls_of_influencer = _get_last_n_video_links(api_key=YOUTUBE_API_KEY, channel_name=influencer, max_results=2)
            if not video_urls_of_influencer:
                print(f"Influencer named {influencer} not found, continuing...")
                continue
            video_urls.extend(video_urls_of_influencer)
        except Exception as e:
            print(f"Error fetching videos for influencer {influencer}: {e}")
            traceback.print_exc()

    video_transcripts = ""
    for video_url in video_urls:
        try:
            video_id = video_url.split("v=")[-1]
            transcripts = YouTubeTranscriptApi.get_transcript(video_id, languages=["tr","en"])

            # Fetch metadata using the YouTube API
            youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)
            video_request = youtube.videos().list(part="snippet", id=video_id)
            video_response = video_request.execute()

            if not video_response["items"]:
                print(f"Metadata not found for video {video_url}, skipping...")
                continue

            snippet = video_response["items"][0]["snippet"]
            title = snippet["title"]
            author = snippet["channelTitle"]
            publish_date = snippet["publishedAt"][:10]

            # Concatenate transcript and filter by date
            text = " ".join([transcript["text"] for transcript in transcripts]).lower()
            today = datetime.datetime.now().date()
            yesterday = str(today - datetime.timedelta(days=1))

            # Include only videos published yesterday and under the character limit
            if publish_date == yesterday and len(text) < 10000:
                video_transcripts += f"{publish_date} {author} : {title}\n{text}\n{video_url}\n\n"

        except Exception as e:
            print(f"Error loading video transcript for {video_url}: {e}")
            traceback.print_exc()
            continue

    try:
        llm = _get_llm("google")
        prompt = f"""
        You are an experienced news summarizer that summarizes yesterday's content on the next day.

        Task:
        Start by naming all YouTube crypto influencers that you will summarize.
        Summarize the news content without missing information.
        Finally check your response and be sure you write the proper names correctly.
        You are receiving a transcript (audio to text converted) input, so your input might include wrong written proper nouns; you should realize the actual proper nouns meant and use correct versions in your answer.
        Do not forget to add the URL of the video after the user tag.

        Format:
        Give detailed answers, for example instead of saying "criticized the SEC's treatment of NFTs as securities", explain the details like "criticized it positively and stated that this development prepares the market for the arrival of the bull".
        Do not forget to indicate these news semantics and potential effects on the crypto market.
        
        Language:
        Your response must be in {language} language, suitable for tweeting, concise, professional, and easy to understand.
        Use a neutral, analytical tone that is professional but accessible.    

        <Example>
        <Human>:
        2024-08-29 uzmancoin : Warren Buffett Sold Again: A First After 24 Years

        [music] uzman kinen (from coin) hello everyone.
        I'm Simay Ergin, it's Thursday, August 29th.
        Important news headlines about crypto are as follows...

        https://www.youtube.com/watch?v=KgFhZn9ecbw

        2024-08-29 techinsights : Elon Musk's Surprising Move: Major Stock Sale

        [music] Welcome to TechInsights, I'm your host Jason Blake.
        Today is Saturday, September 14th and we will share important technology news with you...

        https://www.youtube.com/watch?v=KGauaKu9kF4

        <AI>:
        Below is the summary of the news video shared by uzmancoin and techinsights channels yesterday and the potential impact of this news on the crypto market...
        Now, it’s your turn. Provide the summary in {language} language:
        """
        print(video_transcripts)
        if len(video_transcripts) > 10:
            final_answer = _get_answer_from_llm(llm=llm, prompt=prompt, context=video_transcripts)
            return final_answer.replace("**", "")
        else:
            print(f"No YouTube news videos published yesterday, passing {video_transcripts}")
            return ""
    except Exception as e:
        print(f"Error while getting answer from LLM: {e}")
        traceback.print_exc()

def _get_last_n_video_links(api_key, channel_name, max_results=10) -> list:
    try:
        channel_id = _get_youtube_channel_id(api_key=api_key, channel_name=channel_name)
        youtube = build('youtube', 'v3', developerKey=api_key)

        # Get a larger set of short and medium-length videos ordered by date
        short_videos_response = youtube.search().list(
            channelId=channel_id,
            type='video',
            part='id',
            order='date',
            maxResults=max_results,
            videoDuration='short'
        ).execute()

        medium_videos_response = youtube.search().list(
            channelId=channel_id,
            type='video',
            part='id',
            order='date',
            maxResults=max_results,
            videoDuration='medium',
        ).execute()

        # Combine results from both queries
        combined_videos = short_videos_response['items'] + medium_videos_response['items']

        # Construct video links, excluding Shorts
        video_links = [
            'https://www.youtube.com/watch?v=' + item['id']['videoId']
            for item in combined_videos
        ]
        return video_links[:max_results]
    except Exception as e:
        print(f"Error fetching video links for channel {channel_name}: {e}")
        traceback.print_exc()
        return []

def _get_youtube_channel_id(api_key, channel_name):
    try:
        youtube = build('youtube', 'v3', developerKey=api_key)

        # Search for the channel by name
        search_response = youtube.search().list(
            q=channel_name,
            type='channel',
            part='id'
        ).execute()

        # Extract the channel ID
        channel_id = search_response['items'][0]['id']['channelId']
        return channel_id
    except Exception as e:
        print(f"Error fetching channel ID for {channel_name}: {e}")
        traceback.print_exc()
        return None

def news_analyser(language:str) -> str:
    NEWS_API_API_KEY = os.getenv("NEWS_API_API_KEY")
    NEWS_DATA_IO_API_KEY = os.getenv("NEWS_DATA_IO_API_KEY")
    query_list = [
            'economy AND cryptocurrencies',
            'global conflicts AND declaration of war',
            'cryptocurrency regulatory changes OR cryptocurrency news',
            'major cryptocurrency holdings of the corporations OR investments in cryptocurrencies OR ETF approval OR SEC',
            'blockchain protocol upgrades OR new blockchain applications OR technological advancements blockchain',
    ]
    
    article_list = []
    for query in query_list:
        articles = _fetch_news(query=query, api_key=NEWS_API_API_KEY, backup_api_key=NEWS_DATA_IO_API_KEY)
        article_list.extend(articles)
        time.sleep(1)
    print(article_list)
    article_info = _convert_to_human_readable(article_list)
    print(article_info)
    llm = _get_llm("google")
    prompt =f"""
    You are an experienced news summarizer that summarize blockchain news and comment how these news might affect the market in the short term.

    Task:
    Summarize the news content without missing information.

    Format:
    Give detailed answers, for example instead of saying "criticized the SEC's treatment of NFTs as securities", explain the details like "criticized it positively and stated that this development "prepares the market for the arrival of the bull".
    Do not forget to indicate these news semantics and potential effects on the crypto market.
    Divide each part with "----------" symbols so they can be seperated and tweeted individually.
    
    Language:
    Your response must be in {language} language, suitable for tweeting, concise, professional, and easy to understand.
    Use a neutral, analytical tone that is professional but accessible.    

    <Example>
    <Human>:
    Source: newsBTC
    Author: Ronaldo Marquez
    Title: BlackRock Continues To Buy Bitcoin: Holdings Now Reach 358,000 BTC Worth $22 Billion
    Published Date: 2024-09-26T11:00:19Z
    Content: In less than nine months since the launch of its Bitcoin exchange-traded fund (ETF) following the approval of these investment vehicles by the US Securities and Exchange Commission (SEC), asset manag… [+3413 chars]...  
    Read more: http://www.newsbtc.com/bitcoin-news/blackrock-continues-to-buy-bitcoin-holdings-now-reach-358000-btc-worth-22-billion/

    Source: International Business Times
    Author: Marvie Basilan
    Title: Crypto Advocate Mark Cuban Eyes Replacing Gary Gensler As SEC Chair
    Published Date: 2024-09-26T10:00:43Z
    Content: Billionaire and Shark Tank investor Mark Cuban has seen his fair share of huge roles in the corporate world – now he wants a top position at what could be the most contentious agency for the crypto industry....
    Read more: https://www.ibtimes.com/crypto-advocate-mark-cuban-eyes-replacing-gary-gensler-sec-chair-3744555

    <AI>:
    Below are the news that could affect the price of cryptocurrencies:
    \n 1️⃣ newsBTC/Ronaldo Marquez: http://www.newsbtc.com/bitcoin-news/blackrock-continues-to-buy-bitcoin-holdings-now-reach-358000-btc-worth-22-billion/
    - BlackRock, the world's largest asset manager, continues to increase its Bitcoin holdings.
    - After the SEC approved a Bitcoin exchange-traded fund (ETF), BlackRock's Bitcoin holdings reached 358,000 BTC, currently valued at around $22 billion.
    - Reaching this level in just nine months shows that traditional financial institutions are growing their confidence in crypto.
    ----------
    \n 2️⃣International Business Times/Marvie Basilan: https://www.ibtimes.com/crypto-advocate-mark-cuban-eyes-replacing-gary-gensler-sec-chair-3744555
    - Billionaire investor and cryptocurrency advocate Mark Cuban has announced that he is considering running for the chairmanship of the U.S. Securities and Exchange Commission (SEC).
    - Cuban criticized the current chairman Gary Gensler's stance towards the cryptocurrency sector, stating that he would adopt a more innovative and supportive approach.
    ----------
    \n These developments, IN THE SHORT TERM, a major financial player like BlackRock purchasing BTC could affect the markets upwards in the short term.
    Cuban's possible chairmanship can be interpreted as a positive development for the cryptocurrency markets. This situation can provide more regulatory certainty and institutional adoption in the long term.
    The continuation of ETF approvals is likely to increase liquidity in the crypto market and allow the market to mature.
    
    Now, it’s your turn. Provide the summary in {language} language:
    """
    if len(article_info) > 10:
        final_answer = _get_answer_from_llm(llm=llm, prompt=prompt,context=article_info)
        return final_answer.replace("**","")
    else:
        print(f"No articles found, potential error for: {article_list}")
        return ""


def _fetch_news(query:str, api_key:str, backup_api_key:str)->list:
    page_size = 5
    today = datetime.datetime.now().date()
    yesterday = str(today - datetime.timedelta(days=1))
    url = f'https://newsapi.org/v2/everything?q={query}&pageSize={page_size}&from={yesterday}&to={yesterday}&sortBy=popularity&apiKey={api_key}'
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()['articles']
    else:
        print(f"Failed to fetch news from NewsAPI: {response.status_code}  {response.text} Trying NewsDataIO...")
        # Newsdata.io is the backup because 20 request limit with crypto title is banned
        fallback_url = f'https://newsdata.io/api/1/news?apikey={backup_api_key}&q={query}'
        fallback_response = requests.get(fallback_url)
        if fallback_response.status_code == 200:
            return fallback_response.json()['results']
        else:
            print(f"Failed to fetch news from both newsapi.org and newsdata.io: {fallback_response.status_code}  {fallback_response.text}")
            return []

def _convert_to_human_readable(articles:list) -> str:
    readable_string = ""
    for article in articles:
        if article['author'] != None:
            # Extract the required fields
            source_name = article['source']['name']
            author = article['author']
            title = article['title']
            description = article['description']
            published_date = article['publishedAt']
            url = article['url']
            # Append a formatted string to the readable_string
            readable_string += f"Source: {source_name}\n"
            readable_string += f"Author: {author}\n"
            readable_string += f"Title: {title}\n"
            readable_string += f"Published Date: {published_date}\n"
            readable_string += f"Description: {description}...\n"
            readable_string += f"Read more: {url}\n"
            readable_string += "\n"
    return readable_string

if __name__ == '__main__':
    
    #YOUTUBE_INFLUENCERS = ["uzmancoin", "BTCHaberTV"]
    #youtuber_influencer_analysis = youtuber_analyser(youtube_influencers=YOUTUBE_INFLUENCERS, language='EN')
    #print(youtuber_influencer_analysis)

    #llm_summary, operation = influencer_analyser(coin_count=20, file_path='tweets.csv')
    #print(operation)
    #print(llm_summary)

    #print(news_analyser(language="EN"))
    #print(get_trend_topics(language="EN"))
    btc_dict, eth_dict = check_new_ath()
    ath_message = "new high"
    btc_message= "new high"
    ath_new = ""

    if 'Bitcoin' in btc_dict:
        ath_new += f"🪙 $BTC{ath_message}{btc_dict['Bitcoin']}$ 💸\n"
    else:
        print(btc_dict['info'])
    if 'Ethereum' in eth_dict:
        ath_new += f"♦ $ETH{ath_message}{eth_dict['Ethereum']}$ 💸\n"
    else:
        print(eth_dict['info'])
    
    if ath_new:
        print("posted", ath_new)