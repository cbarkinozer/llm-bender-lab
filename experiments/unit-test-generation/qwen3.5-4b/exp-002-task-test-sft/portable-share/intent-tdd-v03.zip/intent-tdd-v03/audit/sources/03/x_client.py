import requests
from requests_oauthlib import OAuth1Session
import pandas as pd
import time
from datetime import datetime, timedelta, timezone

def post(consumer_key: str, consumer_secret: str, access_token: str, access_secret: str, text: str, is_premium: bool = False, split_by_string: bool = False, post_id: str = None) -> dict:
    if is_premium:
        max_post_length = 25000
        if split_by_string:
            result = _split_text_by_string(text, symbol="----------", in_groups_of=5)
        elif len(text) > max_post_length:
            result = _split_text_by_length(text, max_post_length)
        else:
            result = [text]
    else:
        result = _split_text_by_length(text=text, max_length=280)

    oauth = OAuth1Session(
        consumer_key,
        client_secret=consumer_secret,
        resource_owner_key=access_token,
        resource_owner_secret=access_secret
    )

    response_data = None  # Initialize response_data to avoid UnboundLocalError

    for text_chunk in result:
        print(len(text_chunk))
        print(text_chunk)
        print("********************")
        
        # Create the data payload; only include "reply" if there's a post_id
        data = {"text": text_chunk}
        if post_id:
            data["reply"] = {"in_reply_to_tweet_id": post_id}

        response = oauth.post(
            url="https://api.twitter.com/2/tweets",
            json=data
        )

        if response.status_code != 201:
            print(f"Error: {response.status_code}, {response.text}")
            break

        response_data = response.json()  # Set response_data only if successful
        post_id = response_data["data"]["id"]  # Update post_id to thread next tweet if necessary

    return response_data


def _split_text_by_string(text: str, symbol: str, in_groups_of: int) -> list:
    parts = text.split(symbol)
    parts = [part.strip() for part in parts]
    grouped_parts = [' \n'.join(parts[i:i+in_groups_of]) for i in range(0, len(parts), in_groups_of)]
    return grouped_parts


def _split_text_by_length(text: str, max_length: int) -> list:
    text = text.replace(".\n", "[END_NEWLINE]").replace(". ", "[END_PERIOD]")
    sentences = text.split("[END_PERIOD]")
    parts = []
    current_part = ""
    for sentence in sentences:
        if "[END_NEWLINE]" in sentence:
            sentence = sentence.replace("[END_NEWLINE]", ".\n")
        else:
            sentence = sentence + ". "
        sentence = sentence.strip()
        if len(current_part) + len(sentence) <= max_length:
            current_part += " " + sentence if current_part else sentence
        else:
            if current_part:
                parts.append(current_part)
            current_part = sentence
    if current_part:
        parts.append(current_part)
    parts = [part.rstrip() for part in parts]
    return parts


def get_posts_of_username(bearer_token: str, influencer_dict: dict[str, str]) -> pd.DataFrame:
    today = datetime.now(timezone.utc)
    start_date = (today - timedelta(days=2)).replace(microsecond=0).strftime('%Y-%m-%dT%H:%M:%SZ')
    end_date = (today - timedelta(days=1)).replace(microsecond=0).strftime('%Y-%m-%dT%H:%M:%SZ')

    headers = {"Authorization": f"Bearer {bearer_token}"}
    tweets_data = []

    for username, user_id in influencer_dict.items():
        url = f"https://api.twitter.com/2/users/{user_id}/tweets"
        params = {
            "max_results": 5,
            "tweet.fields": "id,text",
            "exclude": "replies,retweets",
            "start_time": start_date,
            "end_time": end_date
        }

        while True:
            try:
                response = requests.get(url, headers=headers, params=params)
                if response.status_code == 429:
                    wait_min = 15
                    print(f"(Normal for couple of times) Rate limit exceeded for {username}. Retrying after {wait_min} minutes...")
                    time.sleep(wait_min * 60)
                elif response.status_code != 200:
                    print(f"Error fetching tweets: {response.status_code}, {response.text}")
                    break
                else:
                    response_data = response.json()
                    
                    # Process tweet data
                    if 'data' in response_data:
                        for tweet in response_data['data']:
                            tweet_url = f"https://twitter.com/{username}/status/{tweet['id']}"
                            tweets_data.append({
                                'account': user_id,
                                'user': username,
                                'text': tweet['text'],
                                'url': tweet_url
                            })
                    break
            except Exception as e:
                print(f"An error occurred: {e}")
                break
        time.sleep(5)

    # Remove 'media' from DataFrame columns as it's no longer used
    df = pd.DataFrame(tweets_data, columns=["account", "user", "text", "url"])
    return df


if __name__ == "__main__":
    input_text = """
    TESTESTESTESTEST    
    UYARI: Yatırım tavsiyesi DEĞİLDİR!
    ----------
    """
    import os
    
    # Replace with your actual consumer keys and tokens
    consumer_key = os.getenv("CONSUMER_KEY_TR")
    consumer_secret = os.getenv("CONSUMER_SECRET_TR")
    access_token = os.getenv("ACESS_TOKEN_TR")
    access_token_secret = os.getenv("ACCESS_SECRET_TR")

    # Post a tweet
    tweet_response = post(consumer_key, consumer_secret, access_token, access_token_secret, input_text, is_premium=True, split_by_string=True)
    print(tweet_response)

    # Get posts from a user
    bearer_token = os.getenv("BEARER_TOKEN_TR")  # For the get_posts_of_username function
    influencer_dict = {"CryptoKemal": "887419466144940032"}
    df = get_posts_of_username(bearer_token=bearer_token, influencer_dict=influencer_dict)
    print(df)
