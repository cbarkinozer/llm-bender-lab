import yfinance as yf
import talib
import plotly.graph_objects as go
import pandas as pd
from plotly.subplots import make_subplots
from dotenv import load_dotenv
import os
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_openai import ChatOpenAI
from langchain_openai import AzureOpenAI
from langchain_groq import ChatGroq
import numpy as np
import requests
import logging
import plotly.io as pio

logging.basicConfig(level=logging.INFO)

is_loaded = load_dotenv(".env")
    
def get_coin_ticker(coin_name:str):
    base_url = "https://api.coingecko.com/api/v3"
    coin_url = f"{base_url}/coins/{coin_name}"

    try:
        response = requests.get(coin_url)
        response.raise_for_status()
        data = response.json()
        return data.get("symbol")
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching data for {coin_name}: {e}")
        return None

def fetch_coin_price(coin_name='BTC', period='2y', interval='1d'):
    ticker = coin_name + '-USD'
    coin = yf.Ticker(ticker)
    data = coin.history(period=period, interval=interval)
    data.reset_index(inplace=True)
    return data

def calculate_indicators(long_data, period=14):

    data = long_data.iloc[-30:].copy()

    # SMA
    data['SMA'] = talib.SMA(data['Close'], timeperiod=period)
    
    # RSI
    data['RSI'] = talib.RSI(data['Close'], timeperiod=period)
    
    # ADX
    data['ADX'] = talib.ADX(data['High'],data['Low'],data['Close'],timeperiod=period)

    # -DI
    TR = pd.DataFrame(index=data.index)
    TR['TR'] = data['High'] - data['Low']
    TR['h_l'] = abs(data['High'] - data['Close'].shift(1))
    TR['l_c'] = abs(data['Low'] - data['Close'].shift(1))
    TR['TR'] = TR[['TR', 'h_l', 'l_c']].max(axis=1)
    DM = pd.DataFrame(index=data.index)
    DM['-DM'] = data['Low'].diff()
    DM['-DM'] = DM['-DM'].apply(lambda x: x if x < 0 else 0)
    smoothed_tr = TR['TR'].ewm(span=period).mean()
    smoothed_minus_dm = -DM['-DM'].ewm(span=period).mean()
    data['-DI'] = 100 * smoothed_minus_dm / smoothed_tr

    # +DI
    DM['+DM'] = data['High'].diff()
    DM['+DM'] = DM['+DM'].apply(lambda x: x if x > 0 else 0)
    smoothed_plus_dm = DM['+DM'].ewm(span=period).mean()
    data['+DI'] = 100 * smoothed_plus_dm / smoothed_tr
    
    # Bollinger Bands
    data['upper_band'], data['middle_band'], data['lower_band'] = talib.BBANDS(data['Close'], timeperiod=20, nbdevup=2, nbdevdn=2)
    
    # ATR
    data['ATR'] = talib.ATR(data['High'], data['Low'], data['Close'], timeperiod=period)
    
    # Stochastic Oscillator
    data['slowk'], data['slowd'] = talib.STOCH(data['High'], data['Low'], data['Close'], fastk_period=period, slowk_period=3, slowd_period=3)
    
    # CCI
    data['CCI'] = talib.CCI(data['High'], data['Low'], data['Close'], timeperiod=period)
    
    # Parabolic SAR
    data['SAR'] = talib.SAR(data['High'], data['Low'], acceleration=0.02, maximum=0.2)

    # Previous Performance Potential
    data['Previous Performance'], data['Previous Performance Period'] = calculate_max_percentage_gain(long_data=long_data)
    
    return data

def calculate_max_percentage_gain(long_data):
    """
    Find the maximum value increase and return it with the day difference.

    Input:
        DataFrame with columns: Date, Open, High, Low, Close, Volume, Dividends, Stock Splits

    Output:
        max_gain (%): Maximum gain percentage
        day_difference(days): Day difference between the start and end dates
    """
    long_data['Close_Log_Return'] = np.log(long_data['Close']).diff()
    long_data['Cumulative_Return'] = (1 + long_data['Close_Log_Return']).cumprod()

    max_cumulative_return = long_data['Cumulative_Return'].max()
    max_cumulative_return_index = long_data['Cumulative_Return'].idxmax()
    previous_min_cumulative_return_index = long_data['Cumulative_Return'][:max_cumulative_return_index].idxmin()
    day_difference = max_cumulative_return_index - previous_min_cumulative_return_index

    max_gain_percentage = (max_cumulative_return - 1) * 100

    return max_gain_percentage, day_difference


def generate_signals(data):
    signals = []

    # Define colors in acceptable format
    color_map = {
        "green": "rgb(0, 128, 0)",
        "red": "rgb(255, 0, 0)",
        "gray": "rgb(128, 128, 128)"
    }

    # SMA
    if data['Close'].iloc[-1] > data['SMA'].iloc[-1]:
        signals.append(("The 14-period SMA is trending upwards. UP.", color_map["green"]))
    else:
        signals.append(("The 14-period SMA is trending downwards. DOWN.", color_map["red"]))

    # RSI
    if data['RSI'].iloc[-1] > 80:
        signals.append((f"The RSI is {data['RSI'].iloc[-1]} which is currently above 70, suggesting the coin is overbought. DOWN.", color_map["red"]))
    elif data['RSI'].iloc[-1] < 20:
        signals.append((f"The RSI is {data['RSI'].iloc[-1]} which is below 30, indicating the coin is oversold.", color_map["green"]))
    else:
        signals.append((f"The RSI is {data['RSI'].iloc[-1]} which is between 30 and 70, indicating that the coin is neither overbought nor oversold. NEUTRAL.", color_map["gray"]))

    if data['ADX'].iloc[-1] > 40:
        if data['+DI'].iloc[-1] > data['-DI'].iloc[-1]:
            signals.append(("The trend is strong and bullish. UP.", color_map["green"]))
        elif data['+DI'].iloc[-1] < data['-DI'].iloc[-1]:
            signals.append(("The trend is strong and bearish. DOWN.", color_map["red"]))
        else:
            signals.append(("The trend is strong but direction is unclear. NEUTRAL.", color_map["gray"]))
    else:
        signals.append(("The trend is weak. No signal.", color_map["gray"]))

    # Bollinger Bands
    if data['Close'].iloc[-1] > data['upper_band'].iloc[-1]:
        signals.append(("The price is touching the upper Bollinger Band, suggesting the coin might be overbought. DOWN.", color_map["red"]))
    elif data['Close'].iloc[-1] < data['lower_band'].iloc[-1]:
        signals.append(("The price is touching the lower Bollinger Band, indicating the coin might be oversold. UP.", color_map["green"]))
    else:
        signals.append(("The price is within the Bollinger Bands, indicating normal market conditions. NEUTRAL.", color_map["gray"]))

    # ATR
    if data['ATR'].iloc[-1] > data['ATR'].rolling(window=14).mean().iloc[-1]:
        signals.append(("The ATR is increasing, indicating higher market volatility.", color_map["gray"]))
    else:
        signals.append(("The ATR is decreasing, indicating lower market volatility.", color_map["gray"]))

    # Stochastic Oscillator
    if data['slowk'].iloc[-1] > data['slowd'].iloc[-1] and data['slowk'].iloc[-1] < 10:
        signals.append((f"The slowk line {data['slowk'].iloc[-1]} has crossed above the slowd line {data['slowd'].iloc[-1]} in the oversold territory. UP.", color_map["green"]))
    elif data['slowk'].iloc[-1] < data['slowd'].iloc[-1] and data['slowk'].iloc[-1] > 90:
        signals.append((f"The slowk line {data['slowk'].iloc[-1]} has crossed below the slowd line {data['slowd'].iloc[-1]} in the overbought territory. DOWN.", color_map["red"]))
    else:
        signals.append(("The Stochastic Oscillator indicates that the coin is neither in the overbought nor oversold territory. NEUTRAL.", color_map["gray"]))

    # CCI
    if data['CCI'].iloc[-1] > 200:
        signals.append((f"The CCI is {data['CCI'].iloc[-1]} which is above +200, indicating strong upward momentum. UP.", color_map["green"]))
    elif data['CCI'].iloc[-1] < -200:
        signals.append((f"The CCI is {data['CCI'].iloc[-1]} which is below -200, indicating strong downward momentum. DOWN.", color_map["red"]))
    else:
        signals.append((f"The CCI is {data['CCI'].iloc[-1]} which is between -200 and +200, NEUTRAL.", color_map["gray"]))

    # Parabolic SAR
    if data['Close'].iloc[-1] > data['SAR'].iloc[-1]:
        signals.append((f"The price {data['Close'].iloc[-1]} is above the {data['SAR'].iloc[-1]} Parabolic SAR, indicating an uptrend. UP.", color_map["green"]))
    else:
        signals.append((f"The price {data['Close'].iloc[-1]} is below the {data['SAR'].iloc[-1]} Parabolic SAR, indicating a downtrend. DOWN.", color_map["red"]))
    
    # Previous Performance Potential
    x = round(data['Previous Performance'].iloc[-1] / 100, 1)
    days = data['Previous Performance Period'].iloc[-1]
    if x < 1:
        signals.append((f"{x}x in {days} days. Bad performance. Do NOT UP.", color_map["red"]))
    elif x < 10:
        if days > 360:
            signals.append((f"{x}x in {days} days. Did not perform much. NEUTRAL.", color_map["gray"]))
        else:
            signals.append((f"{x}x in {days} days. Good potential. 1 out of 5. Optionally UP.", color_map["gray"]))
    elif x >= 10 and x <= 100:
        if days < 360:
            signals.append((f"{x}x in {days} days. Great potential. 2 out of 5. You can UP.", color_map["gray"]))
        else:
            signals.append((f"{x}x in {days} days. High potential. 3 out of 5. You should UP.", color_map["green"]))
    elif x > 100:
        if days < 360:
            signals.append((f"{x}x in {days} days. High risk high potential. 4 out of 5. Very risky but UP.", color_map["green"]))
        else:
            signals.append((f"{x}x in {days} days. High potential. 5 out of 5. Definetely UP.", color_map["green"]))


    return signals

def plot_data(data, long_data, coin_name, signals) -> go.Figure:
    # Ensure Date is a datetime object and set as index
    data['Date'] = pd.to_datetime(data['Date'])
    data.set_index('Date', inplace=True)

    fig = make_subplots(rows=10, cols=1, shared_xaxes=True, vertical_spacing=0.02,
                        subplot_titles=('Candlestick Chart','SMA', 'RSI', 'MACD', 'Bollinger Bands',
                                        'Average True Range (ATR)', 'Stochastic Oscillator', 
                                        'Commodity Channel Index (CCI)', 'Parabolic SAR', 'Previous Performance Potential'))

    # Candlestick Chart
    fig.add_trace(go.Candlestick(x=data.index, open=data['Open'], high=data['High'], low=data['Low'], close=data['Close'], name='Candlestick'), row=1, col=1)

    # SMA
    fig.add_trace(go.Scatter(x=data.index, y=data['SMA'], mode='lines', name='SMA(Simple Moving Average)'), row=2, col=1)

    # RSI
    fig.add_trace(go.Scatter(x=data.index, y=data['RSI'], mode='lines', name='RSI(Relative Strength Index )', line=dict(color='orange')), row=3, col=1)

    # ADX
    fig.add_trace(go.Scatter(x=data.index, y=data['ADX'], mode='lines', name='ADX (Average Directional Index)', line=dict(color='blue')), row=4, col=1)

    # Bollinger Bands
    fig.add_trace(go.Scatter(x=data.index, y=data['Close'], mode='lines', name='Price'), row=5, col=1)
    fig.add_trace(go.Scatter(x=data.index, y=data['upper_band'], mode='lines', name='Upper Band'), row=5, col=1)
    fig.add_trace(go.Scatter(x=data.index, y=data['middle_band'], mode='lines', name='Middle Band'), row=5, col=1)
    fig.add_trace(go.Scatter(x=data.index, y=data['lower_band'], mode='lines', name='Lower Band'), row=5, col=1)

    # ATR
    fig.add_trace(go.Scatter(x=data.index, y=data['ATR'], mode='lines', name='ATR(Average True Range)', line=dict(color='purple')), row=6, col=1)

    # Stochastic Oscillator
    fig.add_trace(go.Scatter(x=data.index, y=data['slowk'], mode='lines', name='%K(Current Closing Price)', line=dict(color='blue')), row=7, col=1)
    fig.add_trace(go.Scatter(x=data.index, y=data['slowd'], mode='lines', name='%D(Moving Average)', line=dict(color='red')), row=7, col=1)

    # CCI
    fig.add_trace(go.Scatter(x=data.index, y=data['CCI'], mode='lines', name='CCI(Commodity Channel Index)', line=dict(color='brown')), row=8, col=1)

    # Parabolic SAR
    fig.add_trace(go.Scatter(x=data.index, y=data['Close'], mode='lines', name='Price'), row=9, col=1)
    fig.add_trace(go.Scatter(x=data.index, y=data['SAR'], mode='markers', name='Parabolic SAR(Stop and Reverse)', marker=dict(color='green', size=3)), row=9, col=1)

    # Previous Performance Potential
    fig.add_trace(go.Scatter(x=data.index, y=long_data['Close'], mode='lines', name='Price'), row=10, col=1)

    # Add annotations for each subplot with color-coded signals
    annotations = [
        dict(align='left', xref='paper', yref='paper', x=0.8, y=0.1, text=signals[8][0], font=dict(color=signals[8][1])), # Previous Performance Potential
        dict(align='left', xref='paper', yref='paper', x=0.8, y=0.2, text=signals[7][0],  font=dict(color=signals[7][1])), # SMA
        dict(align='left', xref='paper', yref='paper', x=0.8, y=0.3,  text=signals[6][0], font=dict(color=signals[6][1])), # RSI
        dict(align='left', xref='paper', yref='paper', x=0.8, y=0.4, text=signals[5][0], font=dict(color=signals[5][1])), # ADX
        dict(align='left', xref='paper', yref='paper', x=0.8, y=0.5, text=signals[4][0],  font=dict(color=signals[4][1])),# Boillinger Bands
        dict(align='left', xref='paper', yref='paper', x=0.8, y=0.6, text=signals[3][0],  font=dict(color=signals[3][1])),# ATR
        dict(align='left', xref='paper', yref='paper', x=0.8, y=0.7,  text=signals[2][0], font=dict(color=signals[2][1])), # Stochastic Oscillator
        dict(align='left', xref='paper', yref='paper', x=0.8, y=0.8, text=signals[1][0], font=dict(color=signals[1][1])), # CCI
        dict(align='left', xref='paper', yref='paper', x=0.8, y=0.9, text=signals[0][0], font=dict(color=signals[0][1])), # SAR
    ]

    # Update layout for better spacing
    fig.update_layout(height=2500, width=1400, annotations=annotations, title_text=coin_name+"-USD Analysis", showlegend=True)
    fig.update(layout_xaxis_rangeslider_visible=False)

    # Show plot
    return fig

def _get_llm(model_name:str):
    "Return one of the LangChain LLM's according to the model_name. OpenAI, AzureOpenAI, llama-3 and Gemini-pro is supported."
    try:
        if model_name == "openai":
            OPENAI_KEY = os.getenv("OPENAI_KEY")
            llm = ChatOpenAI(model="gpt-4o",temperature=0,max_tokens=None,timeout=None,max_retries=2,api_key=OPENAI_KEY)
        elif model_name == "azure_openai":
            AZURE_AD_TOKEN = os.getenv("AZURE_AD_TOKEN")
            AZURE_AD_TOKEN_PROVIDER = os.getenv("AZURE_AD_TOKEN_PROVIDER")
            AZURE_DEPLOYMENT = os.getenv("AZURE_DEPLOYMENT")
            AZURE_ENDPOINT = os.getenv("AZURE_ENDPOINT")
            llm = AzureOpenAI(azure_ad_token=AZURE_AD_TOKEN, azure_ad_token_provider=AZURE_AD_TOKEN_PROVIDER, azure_deployment=AZURE_DEPLOYMENT, azure_endpoint=AZURE_ENDPOINT, model="gpt-3.5-turbo-instruct", temperature=0,)
        elif model_name == "llama3":
            GROQ_API_KEY = os.getenv("GROQ_API_KEY")
            llm = ChatGroq(api_key=GROQ_API_KEY, model_name="llama3-70b-8192", temperature=0.0) #llama-3.1-70b-versatile
        else:
            GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
            llm = ChatGoogleGenerativeAI(google_api_key=GOOGLE_API_KEY, model="gemini-1.5-pro", temperature=0)
        return llm
    except Exception as e:
        logging.error(f"Error getting LLM: {e}")
        return None

def _get_answer_from_llm(llm, final_signal):
    prompt = """
    You are an experienced technical analyst who focuses on cryptocurrency trading and coin technical analysis.
    You will be provided with a comprehensive analysis of the multiple signals.
    Offer guidance on whether price to go up, down, or remain neutral according to these signals.
    Your answer tonne should be professional and technical yet easy to understand.
    ONLY ANSWER IN TURKISH.
    
    <Example 1>:
    <HUMAN>:
    SAR: The 14-period SMA is trending downwards. DOWN.
    CCI: The RSI is 42.87951909633019 which is between 30 and 70, indicating that the coin is neither overbought nor oversold. NEUTRAL.
    Stochastic Oscillator: The trend is weak. NEUTRAL.
    ATR: The price is touching the lower Bollinger Band, indicating the coin might be oversold. UP.
    Bollinger Bands: The ATR is decreasing, indicating lower market volatility.
    ADX: The slowk line 8.189480597976749 has crossed above the slowd line 5.825743454950962 in the oversold territory. UP.
    RSI: The CCI is -99.31997156174693 which is between -200 and +200, NEUTRAL.
    SMA: The price 0.00020808108092751354 is below the 0.0003090004458955757 Parabolic SAR, indicating a downtrend. DOWN.
    Previous Performance Potential: 4.7x in 172 days. Good potential. 1 out of 5. Optionally UP.
    
    <AI>:
    YUKARI Sinyalleri: 3 (ATR, ADX, Önceki Performans Potansiyeli)
    AŞAĞI Sinyalleri: 2 (SAR, SMA)
    NÖTR Sinyalleri: 3 (CCI, Stokastik Osilatör, RSI)

    Sinyaller:
    SAR ve SMA, sırasıyla aşağı yönlü trend ve fiyatın Parabolik SAR'ın altında olması nedeniyle düşüşü işaret ediyor.
    Ancak, ATR, ADX ve Önceki Performans Potansiyeli, coin'in aşırı satılmış olabileceği, ADX'te bir boğa geçişi ve iyi geçmiş performansı nedeniyle bir yükseliş öngörüyor.
    8 göstergeden 3'ünün yükseliş sinyali ve 2'sinin düşüş sinyali olması, hafif bir yükseliş eğilimine işaret ediyor.
    Ancak, 3 nötr gösterge bulunması, herhangi bir yönde güçlü bir inancı engelliyor.    

    Tahmin: Hafif Artış.

    Sinyaller ezici bir şekilde yükselişe işaret etmiyor, ancak aşırı satılmış koşullardan bir geri dönüş potansiyeli ve coin'in geçmiş performansı, hafif bir yükseliş yaklaşımını haklı gösterebilir.
    Potansiyel aşağı yönlü riskleri yönetmek için sıkı stop-loss emirleri belirlemek ve pozisyona kademeli olarak girmeyi düşünmek önemlidir.
    Riski azaltmak için, küçük ila orta büyüklükte bir pozisyon boyutu öneririm; stop-loss mevcut fiyatın altında ve kar al hedefi mevcut fiyatın makul bir seviyede üzerinde olacak şekilde ayarlanmalıdır.
    Ayrıca, coin'in fiyat hareketini izlemek ve pozisyonu buna göre ayarlamak kritik önem taşır.
    Daha belirgin sinyallerin ortaya çıkıp daha net bir trend yönü belirlenene kadar bir ticaret kararı vermekten kaçınmak mantıklı olabilir.
    Eğer ticaret yapmanız gerekiyorsa, potansiyel aşağı yönlü riskleri yönetmek için sıkı stop-loss emirleri belirlemek gibi risk yönetimi yaklaşımlarını dikkate alın.

    Now it's your turn:
    """
    
    final_answer = llm.invoke(prompt + final_signal)
    final_answer = final_answer.content
    return final_answer

def technical_analyser(coin_name:str,visualization:bool=True) -> tuple[str, str | None]:
    coin_ticker = get_coin_ticker(coin_name)
    if coin_ticker == None:
        coin_ticker = coin_name
    long_data = fetch_coin_price(coin_name=coin_ticker)
    data = calculate_indicators(long_data=long_data)
    signals = generate_signals(data=data)
    fig_html = None
    if visualization:
        fig = plot_data(data=data, long_data=long_data, coin_name=coin_name, signals=signals)
        fig_html = pio.to_html(fig, full_html=True)
    final_signal = (
        f"SAR: {signals[0][0]}\n"
        f"CCI: {signals[1][0]}\n"
        f"Stochastic Oscillator: {signals[2][0]}\n"
        f"ATR: {signals[3][0]}\n"
        f"Bollinger Bands: {signals[4][0]}\n"
        f"ADX: {signals[5][0]}\n"
        f"RSI: {signals[6][0]}\n"
        f"SMA: {signals[7][0]}\n"
        f"Previous Performance Potential: {signals[8][0]}"
    )
    logging.debug(f"[DEBUG] Final Signal:  {final_signal} \n")
    llm = _get_llm(model_name="llama3")
    final_answer = _get_answer_from_llm(llm=llm, final_signal=final_signal)
    return final_answer, fig_html

if __name__ == '__main__':
    technical_analysis, fig_html = technical_analyser("bitcoin")
    print(fig_html)