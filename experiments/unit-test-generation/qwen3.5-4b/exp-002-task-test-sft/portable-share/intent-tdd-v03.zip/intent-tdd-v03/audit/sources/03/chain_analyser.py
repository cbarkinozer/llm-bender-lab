"""This module analyzes blockchain data directly to assess the state and behavior of the network.
Below are the things that are assesed:
* Network Activity: transaction volume, hash rate.
* Transaction Data: Number, size, and frequency of transactions.
* Address Activity: Analysis of active addresses and large holders (whales).
* Exchange Flows: Monitoring the flow of BTC in and out of exchanges to gauge potential buy/sell pressures.
"""

import requests
import os
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_openai import ChatOpenAI
from langchain_openai import AzureOpenAI
from langchain_groq import ChatGroq
import plotly.graph_objects as go
import logging
import plotly.io as pio

logging.basicConfig(level=logging.INFO)

ETHERSCAN_API_KEY = os.getenv("ETHERSCAN_API_KEY")

def get_market_data(coin_id:str) -> dict:
    """
    Retrieves market data for a given cryptocurrency from the CoinGecko API.

    This function sends a GET request to the CoinGecko API to fetch market data 
    for a specified cryptocurrency by its ID. The data is retrieved in USD.
    """
    url = "https://api.coingecko.com/api/v3/coins/markets"
    params = {'vs_currency': 'usd', 'ids': coin_id}
    response = requests.get(url, params=params)
    if response.status_code == 200:
        data = response.json()
        if data:
            return data[0]
        else:
            logging.error(f"No data found for {coin_id}")
            return None
    else:
        logging.error(f"Failed to fetch data for {coin_id}, status code: {response.status_code}")
        return None

def get_transaction_data(coin_id:str) -> dict:
    """Fetches the 24-hour transaction count and transaction volume for a specified cryptocurrency."""
    if coin_id == "bitcoin":
        url = "https://api.blockchain.info/q/24hrtransactioncount"
        response = requests.get(url)
        number_of_transactions = response.json()
        
        url_volume = "https://api.blockchain.info/q/24hrbtcsent"
        response_volume = requests.get(url_volume)
        transaction_volume = response_volume.json()

        return {
            'number_of_transactions': number_of_transactions,
            'transaction_volume': transaction_volume,  # In BTC
        }
    elif coin_id == "ethereum":
        url = "https://api.etherscan.io/api"
        params = {
            'module': 'proxy',
            'action': 'eth_blockNumber',
            'apikey': ETHERSCAN_API_KEY
        }
        response = requests.get(url, params=params)
        latest_block = int(response.json()['result'], 16)

        params['action'] = 'eth_getBlockTransactionCountByNumber'
        params['tag'] = hex(latest_block)
        response = requests.get(url, params=params)
        number_of_transactions = int(response.json()['result'], 16)

        params['action'] = 'eth_getBlockByNumber'
        params['boolean'] = 'true'
        response = requests.get(url, params=params)
        block_data = response.json()['result']
        
        transaction_volume = sum([int(tx['value'], 16) for tx in block_data['transactions']])

        return {
            'number_of_transactions': number_of_transactions,
            'transaction_volume': transaction_volume / 1e18,  # Convert from Wei to ETH
        }
    else:
        logging.error(f"No transaction data available for {coin_id}")
        return {
            'number_of_transactions': f"No number_of_transactions data available for {coin_id}",
            'transaction_volume': f"No transaction_volume data available for {coin_id}"
        }

def get_exchange_flows(coin_id:str) -> dict:
    """Coming and leaving exchange flows of the bitcoin and ethereum are retrieved from their according APIs."""
    if coin_id == "bitcoin":
        url_inflow = "https://api.blockchain.info/charts/total-bitcoins"
        response_inflow = requests.get(url_inflow)
        inflow_data = response_inflow.json()
        
        exchange_inflow = inflow_data['values'][-1]['y'] if inflow_data['values'] else 0

        url_outflow = "https://api.blockchain.info/charts/market-price"
        response_outflow = requests.get(url_outflow)
        outflow_data = response_outflow.json()
        
        exchange_outflow = outflow_data['values'][-1]['y'] if outflow_data['values'] else 0

        return {
            'exchange_inflow': exchange_inflow,
            'exchange_outflow': exchange_outflow
        }
    elif coin_id == "ethereum":
        url_total_supply = "https://api.etherscan.io/api"
        params = {
            'module': 'stats',
            'action': 'ethsupply',
            'apikey': ETHERSCAN_API_KEY
        }
        response = requests.get(url_total_supply, params=params)
        total_supply_data = response.json()
        
        total_supply = int(total_supply_data['result']) / 1e18 if total_supply_data['status'] == '1' else 0

        # Assuming total inflow and outflow are a fraction of total supply
        # In practice, more specific metrics would be needed from an API
        exchange_inflow = total_supply * 0.05  # Placeholder for demonstration
        exchange_outflow = total_supply * 0.04  # Placeholder for demonstration

        return {
            'exchange_inflow': exchange_inflow,
            'exchange_outflow': exchange_outflow
        }
    else:
        logging.error(f"No exchange flow data available for {coin_id}")
        return {
            'exchange_inflow': f"No exchange_inflow data available for {coin_id}",
            'exchange_outflow': f"No exchange_outflow data available for {coin_id}"
        }

def analyze_data(market_data:dict, transaction_data:dict, exchange_flows:dict) -> str:
    """Indicators are used to create signals by comparing preset fix values."""
    
    coin_name = market_data['name']
    current_price = market_data['current_price']
    market_cap = market_data['market_cap']
    market_cap_rank = market_data['market_cap_rank']
    total_volume = market_data['total_volume']
    price_change_24h = market_data['price_change_24h']
    price_change_percentage_24h = market_data['price_change_percentage_24h']
    market_cap_change_24h = market_data['market_cap_change_24h']
    market_cap_change_percentage_24h = market_data['market_cap_change_percentage_24h']
    circulating_supply = market_data['circulating_supply']
    total_supply = market_data['total_supply']
    all_time_high = market_data['ath']
    ath_change_percentage = market_data['ath_change_percentage']
    ath_date = market_data['ath_date']
    all_time_low = market_data['atl']
    atl_change_percentage = market_data['atl_change_percentage']
    atl_date = market_data['atl_date']
    last_updated = market_data['last_updated']
    number_of_transactions = transaction_data['number_of_transactions']
    transaction_volume = transaction_data['transaction_volume']
    exchange_inflow = exchange_flows['exchange_inflow']
    exchange_outflow = exchange_flows['exchange_outflow']

    chain_analyses = "Chain Analysis:\n"
    analysis = {
        'Coin Name': coin_name,
        'Current Price (USD)': current_price,
        'Market Cap (USD)': market_cap,
        'Market Cap Rank': market_cap_rank,
        'Total Volume (USD)': total_volume,
        'Price Change 24h (USD)': price_change_24h,
        'Price Change Percentage 24h (%)': price_change_percentage_24h,
        'Market Cap Change 24h (USD)': market_cap_change_24h,
        'Market Cap Change Percentage 24h (%)': market_cap_change_percentage_24h,
        'Circulating Supply': circulating_supply,
        'Total Supply': total_supply,
        'All Time High (USD)': all_time_high,
        'ATH Change Percentage (%)': ath_change_percentage,
        'All Time High Date': ath_date,
        'All Time Low (USD)': all_time_low,
        'ATL Change Percentage (%)': atl_change_percentage,
        'All Time Low Date': atl_date,
        'Last Updated': last_updated,
        'Number of Transactions': number_of_transactions,
        'Transaction Volume': transaction_volume,
        'Exchange Inflow': exchange_inflow,
        'Exchange Outflow': exchange_outflow
    }
    
    chain_analyses += "\n"
    chain_analyses += "Indicators:\n"
    for key, value in analysis.items():
        chain_analyses += f"{key}: {value}\n"

    high_price_discount_factor = 0.95  # UP if current price < 95% of all-time high
    low_price_premium_factor = 1.05  # DOWN if current price > 105% of all-time low
    buy_transaction_volume_threshold = 5  # UP if transactions >= 5
    supply_threshold = 1e7
    transaction_threshold = 1e4
    total_volume_threshold = 1e6
    exchange_flow_threshold = 1e3

    chain_analyses += "\n"
    chain_analyses += "Signals:\n"
    # Price-Based Signals
    if price_change_24h >= 0:
        chain_analyses += f"Price increased by {price_change_24h:.2f}% in the last 24 hours. UP \n"
    elif price_change_24h < 0:
        chain_analyses += f"Price decreased by {price_change_24h:.2f}% in the last 24 hours. DOWN \n"
    
    if abs(price_change_percentage_24h) > 5:
        chain_analyses += f"Significant price change of {price_change_percentage_24h:.2f}% in the last 24 hours. \n"

    # Market Cap-Based Signals
    if market_cap_change_24h >= 0:
        chain_analyses += f"Market cap increased by {market_cap_change_24h:.2f}% in the last 24 hours. UP \n"
    elif market_cap_change_24h < 0:
        chain_analyses += f"Market cap decreased by {market_cap_change_24h:.2f}% in the last 24 hours. DOWN \n"
    
    if abs(market_cap_change_percentage_24h) > 5:
        chain_analyses += f"Significant market cap change of {market_cap_change_percentage_24h:.2f}% in the last 24 hours. \n"

    # Volume-Based Signals
    if total_volume >= 1e6:
        chain_analyses += f"High trading volume of {total_volume:.2f}. UP \n"
    elif total_volume < 1e6:
        chain_analyses += f"Low trading volume of {total_volume:.2f}. DOWN \n"

    # ATH/ATL-Based Signals
    if current_price >= (high_price_discount_factor * all_time_high):
        chain_analyses += f"Current price ({current_price:.2f} USD) is approaching all-time high ({all_time_high:.2f} USD). UP \n"
    elif current_price < (low_price_premium_factor * all_time_low):
        chain_analyses += f"Current price ({current_price:.2f} USD) is approaching all-time low ({all_time_low:.2f} USD). DOWN \n"
    
    if abs(ath_change_percentage) > buy_transaction_volume_threshold:
        chain_analyses += f"Significant change from all-time high of {ath_change_percentage:.2f}%. \n"
    if abs(atl_change_percentage) > buy_transaction_volume_threshold:
        chain_analyses += f"Significant change from all-time low of {atl_change_percentage:.2f}%. \n"

    # Supply-Based Signals
    if circulating_supply >= supply_threshold:
        chain_analyses += f"High circulating supply of {circulating_supply:.2f}. \n"
    elif circulating_supply < supply_threshold:
        chain_analyses += f"Low circulating supply of {circulating_supply:.2f}. \n"

    if not isinstance(transaction_volume, str):
        # Transaction-Based Signals
        if transaction_volume >= transaction_threshold :
            chain_analyses += f"High transaction volume of {transaction_volume:.2f}. UP \n"
        elif transaction_volume < transaction_threshold:
            chain_analyses += f"Low transaction volume of {transaction_volume:.2f}. DOWN \n"
        
        if number_of_transactions >= 1000:
            chain_analyses += f"High number of transactions ({number_of_transactions}). UP \n"
        elif number_of_transactions < 1000:
            chain_analyses += f"Low number of transactions ({number_of_transactions}). DOWN \n"

        # Exchange Flow-Based Signals
        if exchange_inflow >= exchange_flow_threshold:
            chain_analyses += f"High exchange inflow of {exchange_inflow:.2f}. \n"
        if exchange_outflow > exchange_flow_threshold:
            chain_analyses += f"High exchange outflow of {exchange_outflow:.2f}. \n"

    # Rank-Based Signals
    if market_cap_rank <= 50:
        chain_analyses += f"Ranked within {market_cap_rank} by marketcap. Cannot be valued too much. NEUTRAL \n"
    elif market_cap_rank > 50 and market_cap_rank <= 200:
        chain_analyses += f"Ranked {market_cap_rank} by marketcap. Not too valuable and pretty know. UP \n"
    elif market_cap_rank > 200 and market_cap_rank <= 400:
        chain_analyses += f"Ranked between {market_cap_rank} by marketcap. Not known, has potential. NEUTRAL \n"
    elif market_cap_rank > 400:
        chain_analyses += f"Ranked {market_cap_rank} by marketcap. Very small marketcap. DOWN \n"

    # Composite Signals
    if (price_change_24h > 0 and
        market_cap_change_24h > 0 and
        total_volume > total_volume_threshold):
        chain_analyses += "Bullish signal: price, market cap, and volume are all positive. UP \n"

    if (price_change_24h < 0 and
        market_cap_change_24h < 0 and
        total_volume < total_volume_threshold):
        chain_analyses += "Bearish signal: price, market cap, and volume are all negative. DOWN \n"

    return chain_analyses

def _get_llm(model_name:str):
    "Return one of the LangChain LLM's according to the model_name. OpenAI, AzureOpenAI, llama-3 and Gemini-pro is supported."
    try:
        if model_name == "openai":
            OPENAI_KEY = os.getenv("OPENAI_KEY")
            llm = ChatOpenAI(model="gpt-4o",temperature=0,max_tokens=None,timeout=None,max_retries=2,api_key=OPENAI_KEY)
        elif model_name == "azure_openai":
            AZURE_AD_TOKEN = os.getenv("AZURE_AD_TOKEN")
            AZURE_AD_TOKEN_PROVIDER = os.getenv("AZURE_AD_TOKEN_PROVIDER")
            AZURE_DEPLOYMENT = os.getenv("AZURE_DEPLOYMENT")
            AZURE_ENDPOINT = os.getenv("AZURE_ENDPOINT")
            llm = AzureOpenAI(azure_ad_token=AZURE_AD_TOKEN, azure_ad_token_provider=AZURE_AD_TOKEN_PROVIDER, azure_deployment=AZURE_DEPLOYMENT, azure_endpoint=AZURE_ENDPOINT, model="gpt-3.5-turbo-instruct", temperature=0,)
        elif model_name == "llama3":
            GROQ_API_KEY = os.getenv("GROQ_API_KEY")
            llm = ChatGroq(api_key=GROQ_API_KEY, model_name="llama3-70b-8192", temperature=0.0) #llama-3.1-70b-versatile
        else:
            GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
            llm = ChatGoogleGenerativeAI(google_api_key=GOOGLE_API_KEY, model="gemini-1.5-pro", temperature=0)
        return llm
    except Exception as e:
        logging.error(f"Error getting LLM: {e}")
        return None

def visualize_data(market_data:dict, transaction_data:dict, exchange_flows:dict) -> go.Figure:
    """ Visualize values in a dashboard."""
    # Extract data
    coin_name = market_data.get('name', 'N/A')
    current_price = market_data.get('current_price', 0)
    market_cap = market_data.get('market_cap', 0)
    market_cap_rank = market_data.get('market_cap_rank', 0)
    total_volume = market_data.get('total_volume', 0)
    price_change_24h = market_data.get('price_change_24h', 0)
    price_change_percentage_24h = market_data.get('price_change_percentage_24h', 0)
    market_cap_change_24h = market_data.get('market_cap_change_24h', 0)
    market_cap_change_percentage_24h = market_data.get('market_cap_change_percentage_24h', 0)
    circulating_supply = market_data.get('circulating_supply', 0)
    total_supply = market_data.get('total_supply', 0)
    all_time_high = market_data.get('ath', 0)
    ath_change_percentage = market_data.get('ath_change_percentage', 0)
    ath_date = market_data.get('ath_date', 'N/A')
    all_time_low = market_data.get('atl', 0)
    atl_change_percentage = market_data.get('atl_change_percentage', 0)
    atl_date = market_data.get('atl_date', 'N/A')
    number_of_transactions = transaction_data.get('number_of_transactions', 0)
    transaction_volume = transaction_data.get('transaction_volume', 0)
    exchange_inflow = exchange_flows.get('exchange_inflow', 0)
    exchange_outflow = exchange_flows.get('exchange_outflow', 0)

    # Create a figure
    fig = go.Figure()

    # Market Data
    fig.add_trace(go.Indicator(
        mode="number+delta",
        value=current_price if isinstance(current_price, (int, float)) else 0,
        delta={'reference': all_time_high, 'relative': True, 'position': "top"},
        title={'text': "📌🏷️Current Price (USD)"},
        domain={'row': 0, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=market_cap if isinstance(market_cap, (int, float)) else 0,
        title={'text': "💰Market Cap (USD)"},
        domain={'row': 0, 'column': 1}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=market_cap_rank if isinstance(market_cap_rank, (int, float)) else 0,
        title={'text': "🥇Market Cap Rank"},
        domain={'row': 1, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=total_volume if isinstance(total_volume, (int, float)) else 0,
        title={'text': "💵Total Volume (USD)"},
        domain={'row': 1, 'column': 1}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=circulating_supply if isinstance(circulating_supply, (int, float)) else 0,
        title={'text': "🔁Circulating Supply"},
        domain={'row': 2, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=total_supply if isinstance(total_supply, (int, float)) else 0,
        title={'text': "🛒Total Supply"},
        domain={'row': 2, 'column': 1}
    ))

    fig.add_trace(go.Indicator(
        mode="number+delta",
        value=ath_change_percentage if isinstance(ath_change_percentage, (int, float)) else 0,
        delta={'position': "top", 'relative': True},
        title={'text': "📈ATH Change Percentage (%)"},
        domain={'row': 3, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=all_time_high if isinstance(all_time_high, (int, float)) else 0,
        title={'text': "📈💲All Time High (USD)"},
        domain={'row': 3, 'column': 1}
    ))

    fig.add_trace(go.Indicator(
        mode="number+delta",
        value=atl_change_percentage if isinstance(atl_change_percentage, (int, float)) else 0,
        delta={'position': "top", 'relative': True},
        title={'text': "📉ATL Change Percentage (%)"},
        domain={'row': 4, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=all_time_low if isinstance(all_time_low, (int, float)) else 0,
        title={'text': "📉💲All Time Low (USD)"},
        domain={'row': 4, 'column': 1}
    ))

    # Transaction Data
    fig.add_trace(go.Indicator(
        mode="number",
        value=number_of_transactions if isinstance(number_of_transactions, (int, float)) else 0,
        title={'text': "🤝Number of Transactions"},
        domain={'row': 5, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=transaction_volume if isinstance(transaction_volume, (int, float)) else 0,
        title={'text': "📊Transaction Volume"},
        domain={'row': 5, 'column': 1}
    ))

    # Exchange Flows
    fig.add_trace(go.Indicator(
        mode="number",
        value=exchange_inflow if isinstance(exchange_inflow, (int, float)) else 0,
        title={'text': "💸Exchange Inflow"},
        domain={'row': 6, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=exchange_outflow if isinstance(exchange_outflow, (int, float)) else 0,
        title={'text': "💸❌Exchange Outflow"},
        domain={'row': 6, 'column': 1}
    ))

    # Price Changes
    fig.add_trace(go.Indicator(
        mode="number+delta",
        value=price_change_24h if isinstance(price_change_24h, (int, float)) else 0,
        delta={'position': "top"},
        title={'text': "Price Change 24h (USD)"},
        domain={'row': 7, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number+delta",
        value=price_change_percentage_24h if isinstance(price_change_percentage_24h, (int, float)) else 0,
        delta={'position': "top", 'relative': True},
        title={'text': "Price Change Percentage 24h (%)"},
        domain={'row': 7, 'column': 1}
    ))

    # Market Cap Changes
    fig.add_trace(go.Indicator(
        mode="number+delta",
        value=market_cap_change_24h if isinstance(market_cap_change_24h, (int, float)) else 0,
        delta={'position': "top"},
        title={'text': "Market Cap Change 24h (USD)"},
        domain={'row': 8, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number+delta",
        value=market_cap_change_percentage_24h if isinstance(market_cap_change_percentage_24h, (int, float)) else 0,
        delta={'position': "top", 'relative': True},
        title={'text': "Market Cap Change Percentage 24h (%)"},
        domain={'row': 8, 'column': 1}
    ))

    # Table for Dates
    fig.add_trace(go.Table(
        header=dict(values=["Metric", "Value"]),
        cells=dict(values=[
            ["ATH Date", "ATL Date"],
            [ath_date if isinstance(ath_date, str) else 'N/A', atl_date if isinstance(atl_date, str) else 'N/A']
        ]),
        domain={'x': [0.5, 1], 'y': [0, 0.20]}
    ))

    # Layout
    fig.update_layout(
        grid={'rows': 11, 'columns': 2, 'pattern': "independent"},
        title="₿ "+coin_name+ " Chain Analysis"
    )

    return fig

def get_answer_from_llm(llm: any, final_signal:str) -> str:
    """An LLM request is send and an answer where indicators and signals are interpreted and summarized is returned."""

    prompt = """
    You are an experienced crypto chain analyst that focuses on cryptocurrency blockchain analysis.
    You will be provided a comprehensive analysis of multiple indicators and signals.
    Offer guidance on whether the price to go up, down, or remain neutral with the help of these signals.
    Your answer tonne should be professional and technical yet easy to understand.
    ONLY ANSWER IN TURKISH.
    
    <Example 1>:
    <HUMAN>:
    Indicators:
    Coin Name: Ethereum
    Current Price (USD): 3633.91
    Market Cap (USD): 437697684171
    Market Cap Rank: 2
    Total Volume (USD): 8845033155
    Price Change 24h (USD): 75.22
    Price Change Percentage 24h (%): 2.1136
    Market Cap Change 24h (USD): 10439283588
    Market Cap Change Percentage 24h (%): 2.44332
    Circulating Supply: 120154584.419976
    Total Supply: 120154584.419976
    All Time High (USD): 4878.26
    ATH Change Percentage (%): -25.39768
    All Time High Date: 2021-11-10T14:24:19.604Z
    All Time Low (USD): 0.432979
    ATL Change Percentage (%): 840424.93064
    All Time Low Date: 2015-10-20T00:00:00.000Z
    Last Updated: 2024-06-16T22:26:08.338Z
    Number of Transactions: 116
    Transaction Volume: 14.074158110666115
    Exchange Inflow: 6118693.31089
    Exchange Outflow: 4894954.648712001

    Signals:
    Price increased by 75.22% in the last 24 hours. UP
    Market cap increased by 10439283588.00% in the last 24 hours. UP
    High trading volume of 8845033155.00. UP
    Significant change from all-time high of -25.40%.
    Significant change from all-time low of 840424.93%.
    High circulating supply of 120154584.42.
    Low transaction volume of 14.07. DOWN
    Low number of transactions (116). DOWN
    High exchange inflow of 6118693.31.
    High exchange outflow of 4894954.65.
    Ranked within top 50. Cannot be valued too much. NEUTRAL
    Bullish signal: price, market cap, and volume are all positive. UP
    
    <AI>:
    İndikatör Özeti:
    - Güncel Fiyat: $3633.91
    - Piyasa Değeri: $437,697,684,171 (2. sırada)
    - 24 Saatlik Fiyat Değişimi: $75.22 (%2.11)
    - 24 Saatlik Piyasa Değeri Değişimi: $10,439,283,588 (%2.44)
    - Dolaşımdaki Arz: 120,154,584.42 ETH
    - Tüm Zamanların En Yüksek Seviyesi (ATH): $4878.26 (ATH'nin %25.40 altında)
    - Tüm Zamanların En Düşük Seviyesi (ATL): $0.432979 (ATL'nin %840424.93 üzerinde)
    - İşlem Hacmi: $8,845,033,155
    - İşlem Sayısı: 116
    - İşlem Hacmi: 14.074 ETH
    - Borsaya Giriş: 6,118,693.31 ETH
    - Borsadan Çıkış: 4,894,954.65 ETH

    Sinyal Analizi:
    - Fiyat Değişimi: Son 24 saat içinde fiyat %2.11 arttı, bu da kısa vadede olumlu bir momentum gösteriyor. (YUKARI Sinyal)
    - Piyasa Değeri Değişimi: Piyasa değerindeki %2.44'lük artış, fiyat hareketiyle uyumlu olup, artan piyasa güvenini işaret ediyor. (YUKARI Sinyal)
    - İşlem Hacmi: Yüksek işlem hacmi, piyasada güçlü ilgi ve aktiviteyi gösteriyor. (YUKARI Sinyal)
    - ATH'den Önemli Değişiklik: Şu an ATH'nin %25.40 altında, eğer piyasa olumlu bir trend izlerse potansiyel büyüme alanı olduğunu gösteriyor. (NÖTR)
    - ATL'den Önemli Değişiklik: Güncel fiyat, ATL'nin oldukça üzerinde olup, uzun vadeli değer kazanımı ve direnç gösteriyor. (NÖTR)
    - Yüksek Dolaşımdaki Arz: Yüksek dolaşımdaki arz likidite potansiyeli gösterebilir, ancak kısa vadeli yukarı/aşağı yönlü tahmini doğrudan etkilemez. (NÖTR)
    - Düşük İşlem Hacmi ve İşlem Sayısı: Düşük ağ aktivitesi, ayı piyasasına işaret edebilir. (AŞAĞI Sinyal)
    - Borsaya Girişler ve Çıkışlar: Yüksek girişler, potansiyel düşüş baskısını gösterebilirken, yüksek çıkışlar birikim veya tutma eğilimini gösterebilir. Burada denge biraz karışık ama çıkışlar nedeniyle birikime doğru hafif bir eğilim var. (NÖTR)
    - Piyasa Değeri Sırası: 2. en büyük kripto para birimi olan Ethereum’un yüksek piyasa değeri, istikrar ve piyasa güvenini gösterir ancak küçük piyasa değerlerine göre büyük bir büyüme potansiyelini sınırlar. (NÖTR)
    - Boğa Bileşik Sinyal: Fiyat hareketi, piyasa değeri artışı ve yüksek işlem hacmindeki genel olumlu hareket, boğa piyasası hissiyatını gösteriyor. (YUKARI Sinyal)

    Tahmin: Hafif yukarı.

    Yukarıdaki indikatörler ve sinyallerin analizine dayanarak, fiyatın yukarı yönlü hareket edeceği tahmin ediliyor.
    Fiyat hareketi, piyasa değeri artışı ve yüksek işlem hacmindeki boğa sinyalleri, düşük işlem hacmi ve işlem sayısından gelen ayı sinyallerinden daha ağır basıyor.
    Ayrıca, piyasa değeri sıralaması ve tarihi fiyat verileri, istikrar ve büyüme potansiyeli açısından bir arka plan sunuyor.
    Potansiyel kayıpları sınırlamak için stop-loss $3400 seviyesinde olabilir.
    Güncel momentum ve boğa indikatörlerine dayanarak hedef fiyat $4000 olabilir.
    Ancak, özellikle ağ aktivitesi (işlem hacmi ve işlem sayısı) ve borsa akışlarına odaklanarak piyasa hissiyatındaki ani değişiklikler için dikkatli olunması önemlidir, çünkü bunlar piyasa davranışında değişim sinyali verebilir.
    
    Now it's your turn:
    """
    final_answer = llm.invoke(prompt + final_signal)
    final_answer = final_answer.content
    return final_answer

def chain_analyser(coin_name:str, visualization:bool=True) -> tuple[str, str]:
    """The main chain analyser class that include the algorithm of the chain analyser. This method should be called from outside of the class."""
    coin_id = coin_name.strip().lower()
    
    market_data = get_market_data(coin_id)
    
    transaction_data = get_transaction_data(coin_id)
    
    exchange_flows = get_exchange_flows(coin_id)
    
    final_signal = analyze_data(market_data, transaction_data, exchange_flows)
    logging.debug(f"[DEBUG] Final Signal:  {final_signal}")

    fig_html = None
    if visualization:
        fig = visualize_data(market_data, transaction_data, exchange_flows)
        fig_html = pio.to_html(fig, full_html=True)

    llm = _get_llm(model_name="llama3")
    final_answer = get_answer_from_llm(llm=llm,final_signal=final_signal)
    return final_answer, fig_html


if __name__ == "__main__":
    final_answer = chain_analyser("bitcoin")
    print(final_answer)

