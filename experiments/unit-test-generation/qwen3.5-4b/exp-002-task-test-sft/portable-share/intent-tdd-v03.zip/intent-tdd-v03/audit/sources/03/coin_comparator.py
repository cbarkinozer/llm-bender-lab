import yfinance as yf
from datetime import datetime, timedelta
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import plotly.io as pio

def _fetch_data(tickers: list, start_date:str=None,end_date:str=None, days:int=None) -> pd.DataFrame:
    """Fetches historical adjusted close price data for a given set of stock tickers."""
    if days:
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)        
    else:
        start_date = datetime.strptime(start_date, '%Y-%m-%d %H:%M:%S')
        end_date = datetime.strptime(end_date, '%Y-%m-%d %H:%M:%S')

    data = yf.download(tickers, start=start_date, end=end_date)['Adj Close']
    data.dropna(axis=1, how='all', inplace=True)
    return data

def _calculate_correlation(data: pd.DataFrame) -> pd.DataFrame:
    """Gets pandas dataframe and return a correlation matrix dataframe"""
    return data.corr()

def _plot_combined(correlation_matrix: pd.DataFrame, data: pd.DataFrame, tickers:list) -> go.Figure:
    """Plots correlation matrix of the tickers (coin tickers list) and the cumulative return graph that compares coins."""

    fig = make_subplots(rows=2, cols=1, subplot_titles=("Price Correlation Heatmap", "Cumulative Returns"))

    heatmap = px.imshow(correlation_matrix, 
                        text_auto=True,
                        x=correlation_matrix.columns, 
                        y=correlation_matrix.index, 
                        color_continuous_scale='RdBu_r')
    
    for trace in heatmap.data:
        fig.add_trace(trace, row=1, col=1)

    cumulative_returns = calculate_cumulative_returns(data)
    for ticker in tickers:
        if ticker in cumulative_returns.columns:
            fig.add_trace(go.Scatter(x=cumulative_returns.index, y=cumulative_returns[ticker], mode='lines', name=ticker), row=2, col=1)
    
    fig.update_layout(title_text="Heatmap and Cumulative Returns", height=800)
    fig.update_layout(coloraxis_showscale=False, showlegend=False)
    return fig

def calculate_cumulative_returns(data: pd.DataFrame):
    return (data / data.iloc[0]) - 1

def coin_comparator(tickers:list, start_date:str, end_date:str, days:int=None) -> str:
    second_prefix = ' 00:00:00'
    start_date += second_prefix
    end_date += second_prefix
    tickers = [ticker.upper() + "-USD" for ticker in tickers]
    data = _fetch_data(tickers, start_date=start_date,end_date=end_date)
    correlation_matrix = _calculate_correlation(data)
    fig = _plot_combined(correlation_matrix, data, tickers)
    fig_html = pio.to_html(fig, full_html=True)
    return fig_html

if __name__ == "__main__":
    start_date='2023-01-13 00:00:00'
    end_date='2024-01-13 00:00:00'
    tickers = ["btc", "eth", "ham", "pepe24478", "floki", "fet"]
    
    coin_comparator(tickers=tickers, start_date=start_date,end_date=end_date,days=None)