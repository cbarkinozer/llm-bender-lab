import requests

COIN_DICT =  {'BTC': 'Bitcoin', 'ETH': 'Ethereum', 'USDT': 'Tether', 'BNB': 'BNB', 'SOL': 'Solana', 'USDC': 'USDC', 'XRP': 'XRP', 'STETH': 'Lido Staked Ether', 'DOGE': 'Dogecoin', 'TRX': 'TRON', 'TON': 'Toncoin', 'ADA': 'Cardano', 'AVAX': 'Avalanche', 'SHIB': 'Shiba Inu', 'WSTETH': 'Wrapped stETH', 'WBTC': 'Wrapped Bitcoin', 'WETH': 'Binance-Peg WETH', 'LINK': 'Chainlink', 'BCH': 'Bitcoin Cash', 'UNI': 'Uniswap', 'SUI': 'Sui', 'DOT': 'Polkadot', 'DAI': 'Dai', 'NEAR': 'NEAR Protocol', 'LEO': 'LEO Token', 'LTC': 'Litecoin', 'TAO': 'Bittensor', 'APT': 'Aptos', 'PEPE': 'Pepe', 'WEETH': 'Wrapped eETH', 'ICP': 'Internet Computer', 'FET': 'Artificial Superintelligence Alliance', 'KAS': 'Kaspa', 'FDUSD': 'First Digital USD', 'POL': 'POL (ex-MATIC)', 'XMR': 'Monero', 'ETC': 'Ethereum Classic', 'WIF': 'dogwifhat', 'XLM': 'Stellar', 'STX': 'Stacks', 'OKB': 'OKB', 'IMX': 'Immutable', 'USDE': 'Ethena USDe', 'AAVE': 'Aave', 'WBT': 'WhiteBIT Coin', 'OP': 'Optimism', 'RENDER': 'Render', 'FIL': 'Filecoin', 'CRO': 'Cronos', 'INJ': 'Injective', 'MNT': 'Mantle', 'ARB': 'Arbitrum', 'FTM': 'Fantom', 'HBAR': 'Hedera', 'VET': 'VeChain', 'ATOM': 'Cosmos Hub', 'RUNE': 'THORChain', 'SEI': 'Sei', 'GRT': 'The Graph', 'BGB': 'Bitget Token', 'BONK': 'Bonk', 'POPCAT': 'Popcat', 'RETH': 'Rocket Pool ETH', 'FLOKI': 'FLOKI', 'THETA': 'Theta Network', 'OM': 'MANTRA', 'AR': 'Arweave', 'METH': 'Mantle Staked Ether', 'MKR': 'Maker', 'GT': 'Gate', 'PYTH': 'Pyth Network', 'TIA': 'Celestia', 'HNT': 'Helium', 'SOLVBTC': 'Solv Protocol SolvBTC', 'JUP': 'Jupiter', 'WLD': 'Worldcoin', 'ONDO': 'Ondo', 'ALGO': 'Algorand', 'MATIC': 'Polygon', 'KCS': 'KuCoin', 'QNT': 'Quant', 'LDO': 'Lido DAO', 'BRETT': 'Brett', 'JASMY': 'JasmyCoin', 'BSV': 'Bitcoin SV', 'BTT': 'BitTorrent', 'ENA': 'Ethena', 'NEIRO': 'Neiro', 'GALA': 'GALA', 'W': 'Wormhole', 'EETH': 'ether.fi Staked ETH', 'FLOW': 'Flow', 'CORE': 'Core', 'FTN': 'Fasttoken', 'AERO': 'Aerodrome Finance', 'STRK': 'Starknet', 'NOT': 'Notcoin', 'BEAM': 'Beam', 'EZETH': 'Renzo Restaked ETH'}

INFLUENCER_DICT_TR = {
    # Yerli
    "Bitcoinmeraklsi": "1057747667860799488",
    "bestenazsullu":"192878768",
    "bucoinedir":"1445365661614620680",
    "burak_tamac":"45526112",
    "CoinDelisi": "897780093665390592",
    "coinuzmann": "1642841449858314242",
    "CryptoKemal":"887419466144940032",
    "CryptoLego0311": "1370713842204999692",
    "cryptododo7": "1365900513338920962",
    "CryptooSun":"969921039273734144",

    "Emreislek":"131285674",
    "_ErkanOz":"91581387",
    "General2024x":"2782176258",
    "GokhanGark": "89994880",
    "GrandeAnaliz":"1321157843974868994",
    "ibrahimklczb":"718794395470925824",
    "iberkeoktay":"1099031051203166220",
    "inancsalman": "1128197251988434944",
    "kahincryptocu": "2546350560",
    "kerimcalender":"93408906",

    "KoinSaati":"1336988102620012545",
    "KriptoMevsimi":"1350366409164025856",
    "Kriptomaniaca":"1327544730775932928",
    "Kriptomessi":"1327998596185284608",
    "MuratMmturk": "1027132653504483328",
    "omerdemircrypto": "1275020496711626756",
    "paramuhendisim":"1449671560298647556",
    "RealYoyowbu": "1412497369082568710",
    "TraderMikabot": "996919700733952000",
    "Ucan_Coin": "1449810845987397636",
    
    "xtrendci": "963501922895433729",
    # Yabancı
    "100Trillionusd":"918804624303382528",
    "Adam3Us":"213236426",
    "Altcoindailyio":"958118843636854784",
    "Altcoingordon":"1354400126857605121",
    "Apompliano":"339061487",
    "AriDavidPaul":"847882255540342784",
    "Cryptocevo":"1962290894",
    "Cryptokaduna":"1103404363861684236",
    "Cryptowizardd":"972970759416111104",
    "Expert_Kripto":"1374680253046603777",
    
    "Koroushak":"1392927426",
    "Martiniguyyt":"782946231551131648",
    "Thedustybc":"913778551555608576",
    "Thekriptolik":"2440507021",
    "Trader_Jibon":"1409903853743480832",
    "Trader_XO":"1381341090",
    "Tradermayne":"2446024556",
    "VitalikButerin":"295218901",
    "WClementeIII":"1270906326823186432",
    "Whalepanda":"2799211554",
    
    "rovercrc":"1353384573435056128",
}

INFLUENCER_DICT_EN = {
    "100Trillionusd": "918804624303382528",
    "100xAltcoinGems": "1517796456949817347",
    "Adam3Us": "213236426",
    "Altcoindailyio": "958118843636854784",
    "Altcoingordon": "1354400126857605121",
    "Apompliano": "339061487",
    "AriDavidPaul": "847882255540342784",
    "BTC_NFT": "1286249381155479553",
    "CryptoCapo_": "988796804446769153",
    "CryptoEmdarks": "4876039539",
    "CryptoThro": "2738087632",
    
    "Cryptocevo": "1962290894",
    "Cryptojack": "1415997802321256453",
    "Cryptokaduna": "1103404363861684236",
    "Cryptowizardd": "972970759416111104",
    "DaanCrypto": "918138253617790976",
    "DylanLeClair_": "1649128015",
    "Expert_Kripto": "1374680253046603777",
    "Koroushak": "1392927426",
    "Martiniguyyt": "782946231551131648",
    "MiceCaller": "1521706806078504961",
    "SalsaTekila": "1566114613",
    
    "SatoshiLite": "14338147",
    "TechDev_52": "443073989",
    "TheRealPlanC": "1301215504686694400",
    "Thedustybc": "913778551555608576",
    "Trader_Jibon": "1409903853743480832",
    "Trader_XO": "1381341090",
    "Tradermayne": "2446024556",
    "VitalikButerin": "295218901",
    "WClementeIII": "1270906326823186432",
    "Whalepanda": "2799211554",
    "itsFoxCrypto": "419697640",
    
    "jackmallers": "2360241314",
    "loomdart": "2603525726",
    "oliverzok": "868522251611766784",
    "rektcapital": "918122676195090433",
    "rogerkver": "176758255",
    "rovercrc": "1353384573435056128"
}


YOUTUBE_INFLUENCERS_TR = ["uzmancoin", "BTCHaberTV"]
YOUTUBE_INFLUENCERS_EN = ["uzmancoin", "BTCHaberTV"]

INTERACTION_TRIGGERS_TR = [
    "Bugünkü özetimize katılıyor musunuz? Beğeni ve retweetlerle destekleyin! 👍",
    "Bu analiz sizce isabetli mi? Fikirlerinizi paylaşın! 💬", 
    "Bu haber kripto dünyasında neyi değiştirecek? Yorumlarda tartışalım! 🧐",
    "Bugün sizin favori kripto haberiniz hangisiydi? Beğenin ve paylaşın! 🔥",
    "Sizce bugün kripto piyasasında neler olacak? En doğru tahmin hangisi? Yorumlarınızı bekliyoruz! 💬",
    "Kripto fenomenlerinden en güncel yorumlar ve özetler burada! Eğer faydalı bulduysanız, beğenmeyi unutmayın. 👍",
    "Bugünün kripto fenomenlerinden özetler burada! Yorumlarda görüşlerinizi paylaşın. 🚀",
    "Piyasadaki son gelişmelerle ilgili neler düşünüyorsunuz? Fenomenlerin analizleri ne kadar doğru? Görüşlerinizi bizimle paylaşın! 💭",
    "Fenomenlerden gelen bu özetler işinize yaradıysa, takip etmeyi, beğenmeyi ve paylaşmayı unutmayın! Kripto haberlerinde ilk siz bilgi sahibi olun. 📢",
    "Kripto piyasasındaki dalgalanmalar hakkında ne düşünüyorsunuz? Fikirlerinizi yorumlarda bizimle paylaşın! 💡",
    "Bu haber sizce piyasalarda nasıl bir etki yaratacak? Yorumlarda görüşlerinizi bekliyoruz! 📊",
    "Favori kripto para fenomeniniz kim? Paylaşımlarını beğendiyseniz destekleyin! 💥",
    "Kripto dünyasındaki son gelişmeleri kaçırmayın! En son haberlerle ilgili düşüncelerinizi paylaşın. 💬",
    "Kripto haberlerini ve analizleri nasıl buluyorsunuz? En doğru tahminler kimden geliyor? Fikirlerinizi yorumlara bırakın! 🧐",
    "Bu kripto analizi sizin portföyünüzü etkiler mi? Yorumlarınızı bekliyoruz! 💭"
]

INTERACTION_TRIGGERS_EN = [
    "Do you agree with our summary today? Support it with likes and retweets! 👍",
    "Do you think this analysis is accurate? Share your thoughts! 💬",
    "What will change the crypto world with this news? Let's discuss in the comments! 🧐",
    "What was your favorite crypto news today? Like and share! 🔥",
    "What do you think will happen in the crypto market today? Which is the most accurate prediction? We are waiting for your comments! 💬",
    "The latest comments and summaries from crypto influencers are here! If you found it useful, don't forget to like it. 👍",
    "Today's summaries from crypto influencers are here! Share your opinions in the comments. 🚀",
    "What do you think about the latest developments in the market? How accurate are the analyses of the influencers? Share your opinions with us! 💭",
    "If these summaries from the influencers were useful to you, follow, Don't forget to like and share! Be the first to know about crypto news. 📢",
    "What do you think about the fluctuations in the crypto market? Share your ideas with us in the comments! 💡",
    "How do you think this news will affect the markets? We are waiting for your opinions in the comments! 📊",
    "Who is your favorite cryptocurrency phenomenon? Support them if you like their posts! 💥",
    "Don't miss the latest developments in the crypto world! Share your thoughts on the latest news. 💬",
    "What do you think about crypto news and analysis? Who makes the most accurate predictions? Leave your ideas in the comments! 🧐",
    "Will this crypto analysis affect your portfolio? We are waiting for your comments! 💭"
]

CLICKBAIT_INFLUENCER_TR = [
    "Kripto fenomenlerin son tüyoları sizi şaşırtabilir!",
    "Piyasaları çalkalayan açıklamalar!",
    "Piyasanın enlerinin görüşlerini sizler için derledik!",
    "Kripto dünyasında neler yaşandı? Detaylar aşağıda!",
    "Fenomenlerin radarındaki o altcoin hangisi?",
    "Fenomenlerden aykırı görüşler!",
    "Fenomenlerin ipuçlarıyla kazancınızı şekillendirebilirsiniz!",
    "Herkesin konuştuğu o coin hakkındaki en popüler yorumlar!",
    "Bu açıklamalar piyasaya dair bildiklerinizi değiştirebilir!"
]

CLICKBAIT_INFLUENCER_EN = [
    "The latest tips from crypto influencers may surprise you!",
    "Statements shaking the markets!",
    "We've gathered the opinions of the top players in the market for you!",
    "What happened in the crypto world? Details below!",
    "Which altcoin is on the radar of the influencers?",
    "Contrary opinions from influencers!",
    "You can shape your profits with the influencers' tips!",
    "The most popular comments about that coin everyone is talking about!",
    "These statements could change what you know about the market!"
]

CLICKBAIT_NEWS_TR = [
    "Kripto dünyasında yaşananlar sizi şaşırtabilir!",
    "Piyasaları etkileyebilecek kripto haberleri burada!",
    "Piyasayı yorumlamadan önce bu haberleri okumak isteyebilirsiniz!",
    "Kripto piyasasında neler oluyor? Şaşırabilirsiniz!",
    "Bu kripto haberleri dengeleri değiştirebilir mi?",
    "Kripto meraklılarını etkileyebilecek önemli kripto haberlerini kaçırmayın!",
    "Kripto para dünyasındaki beklenmedik gelişmeler!",
    "Bu kripto haberleri piyasaları sallayabilir!"
]


CLICKBAIT_NEWS_EN = [
    "What’s happening in the crypto world may surprise you!",
    "Crypto news that could affect the markets is here!",
    "You might want to read these news before commenting on the market!",
    "What’s going on in the crypto market? You might be surprised!",
    "Could these crypto news change the balances?",
    "Don’t miss important crypto news that could affect crypto enthusiasts!",
    "Unexpected developments in the world of cryptocurrency!",
    "These crypto news could shake the markets!"
]


CLICKBAIT_INFLUENCER_SUMMARY_TR = [
    "Kripto fenomenleri hangi coin'ler hakkında ne düşünüyor?",
    "Favori coin'iniz hakkındaki fenomenlerin görüşleri neler?",
    "Fenomenler hangi coin'leri konuşuyor?",
    "Fenomenler coin'ler hakkında olumlu mu olumsuz mu konuşuyorlar?",
    "Hangi coin çok konuşuluyor?",
    "Fenomenlerin radarındaki beklenmedik coin'ler!",
    "Fenomenlerin son paylaşımlarında öne çıkan kripto paralar!",
    "Sosyal medyada çok konuşulan coin'ler hangileri?",
    "Geçtiğimiz gün fenomenlerin konuştuğu en popüler coinler!",
    "Fenomenlerin portföyündeki sürpriz kripto varlıklar!",
]


CLICKBAIT_INFLUENCER_SUMMARY_EN = [
    "What do crypto influencers think about which coins?",
    "What are the influencers' opinions about your favorite coin?",
    "Which coins are the influencers talking about?",
    "Are influencers speaking positively or negatively about the coins?",
    "Which coin is being talked about a lot?",
    "Unexpected coins on the influencers' radar!",
    "Prominent cryptocurrencies in the influencers' latest posts!",
    "Which coins are being talked about a lot on social media?",
    "The most popular coins talked about by influencers in recent days!",
    "Surprising crypto assets in the influencers' portfolios!",
]


CLICKBAIT_YOUTUBER_TR = [
    "Youtube'daki günlük kripto haberleri ne diyor?",
    "Önemli kripto haberlerini kaçırmak istemeyebilirsiniz!",
    "Bu kripto haberini herkes konuşuyor!",
    "Kripto piyasasını ilgilendiren haberler!",
    "Bu habere şaşırabilirsiniz!",
    "Piyasaları sarsan haberler!",
    "Kripto yatırımcıları bu habere dikkat kesiliyor!",
    "Kripto dünyasında neler oluyor?"
]


CLICKBAIT_YOUTUBER_EN = [
    "What do the daily crypto news on YouTube say?",
    "You might not want to miss important crypto news!",
    "Everyone is talking about this crypto news!",
    "News related to the crypto market!",
    "You might be surprised by this news!",
    "News that shakes the markets!",
    "Crypto investors are paying close attention to this news!",
    "What’s happening in the crypto world?"
]


if __name__ == "__main__":
    pass