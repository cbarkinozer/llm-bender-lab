from crypto_influencer_analyser import influencer_analyser, youtuber_analyser, news_analyser, analyze_single_tweet, check_new_ath, get_trend_topics
import x_client
from datetime import datetime
import schedule
import time
import threading
from dotenv import load_dotenv
import os
import random
import shutil
import os
from utils import YOUTUBE_INFLUENCERS_TR, YOUTUBE_INFLUENCERS_EN, INFLUENCER_DICT_TR, INFLUENCER_DICT_EN, INTERACTION_TRIGGERS_TR, INTERACTION_TRIGGERS_EN, CLICKBAIT_YOUTUBER_EN, CLICKBAIT_YOUTUBER_TR, CLICKBAIT_NEWS_EN, CLICKBAIT_NEWS_TR, CLICKBAIT_INFLUENCER_EN, CLICKBAIT_INFLUENCER_TR, CLICKBAIT_INFLUENCER_SUMMARY_EN, CLICKBAIT_INFLUENCER_SUMMARY_TR
import traceback
from fastapi import FastAPI, Form, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse
import uvicorn
from fastapi.middleware.cors import CORSMiddleware
import locale
from coin_analyser import coin_analyser
from coin_comparator import coin_comparator
from datetime import datetime, timedelta

app = FastAPI()

origins=["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"]
)

@app.get("/", tags=["Health Check"])
async def check_health():
    return JSONResponse(content={"success": "true"})

@app.post("/tweet-analyzer")
def tweet_analyzer(tweet_url: str = Form(...), language:str = Form(...)):
    if 'EN' == language:
        CONSUMER_KEY = os.getenv("CONSUMER_KEY_EN")
        CONSUMER_SECRET = os.getenv("CONSUMER_SECRET_EN")
        ACESS_TOKEN = os.getenv("ACESS_TOKEN_EN")
        ACCESS_SECRET = os.getenv("ACCESS_SECRET_EN")
        BEARER_TOKEN = os.getenv("BEARER_TOKEN_EN")
    elif 'TR' == language:
        CONSUMER_KEY = os.getenv("CONSUMER_KEY_TR")
        CONSUMER_SECRET = os.getenv("CONSUMER_SECRET_TR")
        ACESS_TOKEN = os.getenv("ACESS_TOKEN_TR")
        ACCESS_SECRET = os.getenv("ACCESS_SECRET_TR")
        BEARER_TOKEN = os.getenv("BEARER_TOKEN_TR")

    response, status_code = analyze_single_tweet(tweet_url=tweet_url, language=language, consumer_key=CONSUMER_KEY, consumer_secret=CONSUMER_SECRET, access_token=ACESS_TOKEN, access_secret=ACCESS_SECRET, bearer_token=BEARER_TOKEN)
    if status_code == 200:
        return {"response": response}
    else:
        raise HTTPException(status_code=status_code, detail=response)

@app.post("/coin-analyzer")
def coin_analyzer(coin: str = Form(...), start_date:str = Form(None), end_date:str = Form(None), visualization:str = Form(None)):
    if start_date==None or end_date == None:
        today = datetime.today() # Get today's date
        start_date = (today - timedelta(days=1)).strftime('%Y-%m-%d') # from yesterday
        end_date = (today - timedelta(days=0)).strftime('%Y-%m-%d') # to today
    if visualization.lower() == "true":
        visualization = True
    coin_analysis = coin_analyser(coin_name=coin, start_date=start_date, end_date=end_date, visualization=visualization)
    return JSONResponse(content=coin_analysis)

@app.post("/coin-comparator")
def coins_comparator(coin_list: str = Form(...), start_date:str = Form(None), end_date:str = Form(None)):
    if start_date==None or end_date == None:
        today = datetime.today() # Get today's date
        start_date = (today - timedelta(days=1)).strftime('%Y-%m-%d') # from yesterday
        end_date = (today - timedelta(days=0)).strftime('%Y-%m-%d') # to today
    coin_list = coin_list.split(",")
    coin_list = [coin.strip() for coin in coin_list]
    print(coin_list)
    fig_html = coin_comparator(tickers=coin_list, start_date=start_date, end_date=end_date)
    return HTMLResponse(content=fig_html)


# Function to start the FastAPI app
def start_fastapi():
    uvicorn.run(app, host="127.0.0.1", port=5000)

send_tweet_lock = threading.Lock()
stop_event = threading.Event()

def _save_tweets(bearer_token:str,influencer_dict: dict[str, str]) -> bool:
    """For each crypto influencer in the dict, last x amount of tweet is retrieved and saved as csv."""
    try:
        posts = x_client.get_posts_of_username(bearer_token=bearer_token, influencer_dict=influencer_dict)
        if posts.empty:
            print(f"No posts found.")
            return False
        posts.to_csv("tweets.csv", index=False)
        print("TWEETS SAVED SUCCESSFULY")
        return True
    except Exception as e:
        print(f"Failed to save tweets: {e}")
        return False

def _copy_analysed_tweets_csv(source_file: str, destination_dir: str) -> None:
    try:
        base_name = source_file
        destination_file = os.path.join(destination_dir, base_name)
        os.makedirs(destination_dir, exist_ok=True)

        if os.path.exists(destination_file):
            file_name, file_ext = os.path.splitext(base_name)
            counter = 1
            while os.path.exists(destination_file):
                destination_file = os.path.join(destination_dir, f"{file_name}_{counter}{file_ext}")
                counter += 1

        shutil.copy(source_file, destination_file)
        print(f'File copied to {destination_file}')
    except Exception as e:
        print(f"Error copying file: {e}")
        traceback.print_exc()


def send_tweet():
    if stop_event.is_set():
        print("Shutdown in progress, skipping send_tweet.")
        return

    if send_tweet_lock.locked():
        print("Previous send_tweet is still running. Skipping this execution.")
        return

    with send_tweet_lock:
        print("Send Tweet is triggered!")
        start_time = time.time()
        try:
            languages_str = os.getenv("LANGUAGES")
            if languages_str:
                languages = languages_str.split(',')
            else:
                print("LANGUAGES is NOT given in the ENV file!")
                return
            for language in languages:
                try:
                    if 'EN' == language:
                        locale.setlocale(locale.LC_TIME, 'en_US.UTF-8')
                        current_date = datetime.now().date()
                        date = current_date.strftime("%d %B %Y")

                        clickbait_youtuber = CLICKBAIT_YOUTUBER_EN
                        clickbait_news = CLICKBAIT_NEWS_EN
                        clickbait_influencer = CLICKBAIT_INFLUENCER_EN
                        clickbait_influencer_summary = CLICKBAIT_INFLUENCER_SUMMARY_EN
                        interaction_trigger = INTERACTION_TRIGGERS_EN
                        warning = "WARNING: This NOT investment advice!\n I may make mistakes when coming up with a coin name, analyzing how the coin is mentioned, or summarizing tweets."
                        postfix = "I am an AI Crypto analyst and I analyze digital asset prices such as cryptocurrency, Bitcoin, Ethereum, Altcoin, Crypto Prices and Crypto Trading, ensuring that the latest developments and crypto news regarding Blockchain technology are constantly followed. I can process information at a speed, detail and amount that a human cannot. You can follow me for more information and analysis."
                        influencer_dict = INFLUENCER_DICT_EN
                        youtube_influencers = YOUTUBE_INFLUENCERS_EN
                        youtuber_analysis_title = f"\n ▶️🪙🔎 Summary of the Crypto Channels on Youtube - {date}\n"
                        news_analysis_title = f"\n 📰🪙🔎 Crypto News Summary - {date}\n"
                        influencer_analysis_title = f"\n 🪙👥🔍 Summary of the Crypto Influencers on X - {date}\n"
                        influencer_analysis_summary_title = f"\n 🪙👤🔎 Summary of The Opinions of Crypto Influencers on X - {date}\n"
                        destination_dir = 'previous_data_en/'
                        ath_message = "'s new record: "
                        BEARER_TOKEN = os.getenv("BEARER_TOKEN_EN")
                        CONSUMER_KEY = os.getenv("CONSUMER_KEY_EN")
                        CONSUMER_SECRET = os.getenv("CONSUMER_SECRET_EN")
                        ACESS_TOKEN = os.getenv("ACESS_TOKEN_EN")
                        ACCESS_SECRET = os.getenv("ACCESS_SECRET_EN")
                    elif 'TR' == language:
                        locale.setlocale(locale.LC_TIME, 'tr_TR.UTF-8')
                        current_date = datetime.now().date()
                        date = current_date.strftime("%d %B %Y")

                        clickbait_youtuber = CLICKBAIT_YOUTUBER_TR
                        clickbait_news = CLICKBAIT_NEWS_TR
                        clickbait_influencer = CLICKBAIT_INFLUENCER_TR
                        clickbait_influencer_summary = CLICKBAIT_INFLUENCER_SUMMARY_TR
                        interaction_trigger = INTERACTION_TRIGGERS_TR
                        warning = "UYARI: Yatırım tavsiyesi DEĞİLDİR!\n Coin ismi bulurken, coin'den hangi şekilde bahsedildiğini analiz ederken veya tweetleri özetlerken hata yapabilirim."
                        postfix = "Ben Yapay Zeka Kripto analizcisiyim ve kripto para birimi, Bitcoin, Ethereum, Altcoin gibi dijital varlık fiyatlarını, Kripto Fiyatları ve Kripto Ticaretinin analiz edilmesini sağlayarak, Blockchain teknolojisiyle ilgili en son gelişmeler ve kripto haberlerinin sürekli takip edilmesini sağlarım. Bir insanın yapamayacağı hızda, detayda ve miktarda bilgi işleyebilirim. Daha fazla bilgi ve analiz için beni takip edebilirsiniz."
                        influencer_dict = INFLUENCER_DICT_TR
                        youtube_influencers = YOUTUBE_INFLUENCERS_TR
                        youtuber_analysis_title = f"\n ▶️🪙🔎 Youtube'daki Kripto Kanallarının Özeti - {date}\n"
                        news_analysis_title = f"\n 📰🪙🔎 Kripto Haber Özeti - {date}\n"
                        influencer_analysis_title = f"\n 🪙👥🔍 X'deki Kripto Fenomenlerinin Özeti - {date}\n"
                        influencer_analysis_summary_title = f"\n 🪙👤🔎 X'deki Kripto Fenomenlerinin Görüşlerinin Özeti - {date}\n"
                        destination_dir = 'previous_data_tr/'
                        ath_message= "'den yeni rekor: "
                        BEARER_TOKEN = os.getenv("BEARER_TOKEN_TR")
                        CONSUMER_KEY = os.getenv("CONSUMER_KEY_TR")
                        CONSUMER_SECRET = os.getenv("CONSUMER_SECRET_TR")
                        ACESS_TOKEN = os.getenv("ACESS_TOKEN_TR")
                        ACCESS_SECRET = os.getenv("ACCESS_SECRET_TR")
                    else:
                        print("No defined languages are found!")

                    random_clickbait_youtuber = random.choice(clickbait_youtuber)
                    random_clickbait_news = random.choice(clickbait_news)
                    random_clickbait_influencer = random.choice(clickbait_influencer)
                    random_clickbait_influencer_summary = random.choice(clickbait_influencer_summary)
                    
                    
                    random_interaction_trigger1 = random.choice(interaction_trigger)
                    random_interaction_trigger2 = random.choice(interaction_trigger)
                    random_interaction_trigger3 = random.choice(interaction_trigger)
                    random_interaction_trigger4 = random.choice(interaction_trigger)
                    
                    # Part 1: Saving Tweets
                    is_saved = _save_tweets(bearer_token=BEARER_TOKEN, influencer_dict=influencer_dict)

                    # Part 2: Doing Analysis and Sharing
                    if is_saved:
                        youtuber_influencer_analysis = youtuber_analyser(language=language, youtube_influencers=youtube_influencers)
                        news_summary = news_analyser(language=language)
                        btc_dict, eth_dict = check_new_ath()
                        trend_topics = get_trend_topics(language=language)
                        llm_summary, operation = influencer_analyser(language=language, coin_count=20, file_path='tweets.csv')

                        youtuber_analysis = ""
                        if len(youtuber_influencer_analysis) > 10:
                            youtuber_analysis += f"\n {random_clickbait_youtuber} \n"
                            youtuber_analysis += f"🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥\n"
                            youtuber_analysis += youtuber_analysis_title
                            youtuber_analysis += f"\n {youtuber_influencer_analysis} \n"
                            youtuber_analysis += f"\n {postfix} \n"
                            youtuber_analysis += f"\n {random_interaction_trigger1} \n\n"
                            youtuber_analysis += f"\n {warning} \n"
                            youtuber_analysis += f"\n {trend_topics} \n"
                            print(youtuber_analysis)
                            _ = x_client.post(consumer_key=CONSUMER_KEY, consumer_secret=CONSUMER_SECRET, access_token=ACESS_TOKEN, access_secret=ACCESS_SECRET, text=youtuber_analysis, is_premium=True)
                        
                        time.sleep(60)

                        news_analysis = ""
                        if len(news_summary) > 10:
                            news_analysis += f"\n {random_clickbait_news} \n"
                            news_analysis += f"🟨🟨🟨🟨🟨🟨🟨🟨🟨🟨🟨🟨🟨🟨\n"
                            news_analysis += news_analysis_title
                            news_analysis += f"\n {news_summary} \n"
                            news_analysis += f"\n {postfix} \n"
                            news_analysis += f"\n {random_interaction_trigger2} \n\n"
                            news_analysis += f"\n {warning} \n"
                            news_analysis += f"\n {trend_topics} \n"
                            print(news_analysis)
                            _ = x_client.post(consumer_key=CONSUMER_KEY, consumer_secret=CONSUMER_SECRET, access_token=ACESS_TOKEN, access_secret=ACCESS_SECRET, text=news_analysis, is_premium=True, split_by_string=True)
                        
                        time.sleep(60)

                        influencer_analysis = ""
                        if len(llm_summary) > 10:
                            influencer_analysis += f"\n {random_clickbait_influencer} \n"
                            influencer_analysis += f"🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦\n"
                            influencer_analysis += influencer_analysis_title
                            influencer_analysis += f"\n {llm_summary} \n"
                            influencer_analysis += f"\n {postfix} \n"
                            influencer_analysis += f"\n {random_interaction_trigger3} \n\n"
                            influencer_analysis += f"\n {warning} \n"
                            influencer_analysis += f"\n {trend_topics} \n"
                            print(influencer_analysis)
                            _ = x_client.post(consumer_key=CONSUMER_KEY, consumer_secret=CONSUMER_SECRET, access_token=ACESS_TOKEN, access_secret=ACCESS_SECRET, text=influencer_analysis, is_premium=True, split_by_string=True)

                        time.sleep(60)

                        influencer_analysis_summary = ""
                        if len(operation) > 10:
                            influencer_analysis_summary += f"\n {random_clickbait_influencer_summary} \n"
                            influencer_analysis_summary += f"🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩\n"
                            influencer_analysis_summary += influencer_analysis_summary_title
                            influencer_analysis_summary += f"\n {operation} \n"
                            influencer_analysis_summary += f"\n {postfix} \n"
                            influencer_analysis_summary += f"\n {random_interaction_trigger4} \n\n"
                            influencer_analysis_summary += f"\n {warning} \n"
                            influencer_analysis_summary += f"\n {trend_topics} \n"
                            print(influencer_analysis_summary)
                            _ = x_client.post(consumer_key=CONSUMER_KEY, consumer_secret=CONSUMER_SECRET, access_token=ACESS_TOKEN, access_secret=ACCESS_SECRET, text=influencer_analysis_summary, is_premium=True)

                        time.sleep(60)

                        ath_new = ""
                        if 'Bitcoin' in btc_dict:
                            ath_new += f"🪙 $BTC{ath_message}{btc_dict['Bitcoin']}$ 💸\n"
                        else:
                            print(btc_dict['info'])
                        
                        if 'Ethereum' in eth_dict:
                            ath_new += f"♦ $ETH{ath_message}{eth_dict['Ethereum']}$ 💸\n"
                        else:
                            print(eth_dict['info'])
                        
                        if ath_new:
                            _ = x_client.post(consumer_key=CONSUMER_KEY, consumer_secret=CONSUMER_SECRET, access_token=ACESS_TOKEN, access_secret=ACCESS_SECRET, text=ath_new, is_premium=True)

                        _copy_analysed_tweets_csv(source_file='analysed_tweets.csv', destination_dir=destination_dir)

                        end_time = time.time()
                        time_taken = end_time - start_time
                        with open("log.txt", "a", encoding='utf-8') as log_file:
                            log_file.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - Sent Tweet\n")
                            log_file.write(f"Time taken: {time_taken} seconds\n")
                            log_file.write("--------------------------------------------------------------\n")
                        
                        print(f"{language} is SUCCESSFUL!")
                except Exception as e:
                    print(f"Error processing language {language}: {e}")
                    traceback.print_exc()
        except Exception as e:
            print(f"Error in send_tweet: {e}")
            traceback.print_exc()
    print("! ALL SUCCESSFULLY DONE!")


load_dotenv()
POST_TIME = os.getenv("POST_TIME")

schedule.every().day.at(POST_TIME).do(send_tweet)

def run_schedule(stop_event) -> None:
    print(f"Waiting for the right time to get triggered: {POST_TIME}")
    while not stop_event.is_set():
        try:
            schedule.run_pending()
        except Exception as e:
            print(f"Error while running schedule: {e}")
            traceback.print_exc()
        time.sleep(1)
    print("Schedule thread is stopping...")

if __name__ == "__main__":
    # Create the scheduling thread
    schedule_thread = threading.Thread(target=run_schedule, args=(stop_event,))
    schedule_thread.start()

    # Create the FastAPI thread and set it as a daemon
    fastapi_thread = threading.Thread(target=start_fastapi, daemon=True)
    fastapi_thread.start()

    try:
        while schedule_thread.is_alive():
            time.sleep(1)
    except KeyboardInterrupt:
        print("Received exit signal, stopping...")
        stop_event.set()
        schedule_thread.join()