import requests
import os
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_openai import ChatOpenAI
from langchain_openai import AzureOpenAI
from langchain_groq import ChatGroq
from datetime import datetime
import plotly.graph_objects as go
import logging
import plotly.io as pio

logging.basicConfig(level=logging.INFO)

def get_coin_data(coin_name:str) -> dict[str, any]:
    base_url = "https://api.coingecko.com/api/v3"
    coin_url = f"{base_url}/coins/{coin_name}"

    try:
        response = requests.get(coin_url)
        response.raise_for_status()
        data = response.json()

        coin_indicators = {
            "block_time_in_minutes": data.get("block_time_in_minutes"),
            "hashing_algorithm": data.get("hashing_algorithm"),
            "categories": data.get("categories"),
            "description_en": data["description"].get("en"),
            "links_homepage": data["links"].get("homepage"),
            "whitepaper": data["links"].get("whitepaper"),
            "blockchain_site": data["links"].get("blockchain_site"),
            "official_forum_url": data["links"].get("official_forum_url"),
            "social_media": {
                "twitter": data["links"].get("twitter_screen_name"),
                "facebook": data["links"].get("facebook_username"),
                "reddit": data["links"].get("subreddit_url"),
            },
            "github": data["links"].get("repos_url", {}).get("github"),
            "genesis_date": data.get("genesis_date"),
            "sentiment_votes_up_percentage": data.get("sentiment_votes_up_percentage"),
            "sentiment_votes_down_percentage": data.get("sentiment_votes_down_percentage"),
            "watchlist_portfolio_users": data.get("watchlist_portfolio_users"),
            "total_value_locked": data.get("total_value_locked"),
            "community_data_twitter_followers": data["community_data"].get("twitter_followers"),
            "developer_data": data.get("developer_data"),
            "trust_score": data.get("trust_score"),
            "is_anomaly": data.get("is_anomaly"),
            "is_stale": data.get("is_stale"),
        }
        return coin_indicators
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching data for {coin_name}: {e}")
        return None

def get_signal(coin_indicators: dict) -> str:
    """According to the  fixed rules, signals are created from indicators."""
    block_time_in_minutes = coin_indicators["block_time_in_minutes"]
    hashing_algorithm = coin_indicators["hashing_algorithm"]
    links_homepage = coin_indicators["links_homepage"]
    whitepaper = coin_indicators["whitepaper"]
    blockchain_site = coin_indicators["blockchain_site"]
    official_forum_url = coin_indicators["official_forum_url"]
    social_media = coin_indicators["social_media"]
    github = coin_indicators["github"]
    genesis_date = coin_indicators["genesis_date"]
    sentiment_votes_up_percentage = coin_indicators["sentiment_votes_up_percentage"]
    sentiment_votes_down_percentage = coin_indicators["sentiment_votes_down_percentage"]
    watchlist_portfolio_users = coin_indicators["watchlist_portfolio_users"]
    community_data_twitter_followers = coin_indicators["community_data_twitter_followers"]
    developer_data = coin_indicators["developer_data"]
    is_anomaly = coin_indicators["is_anomaly"]
    is_stale = coin_indicators["is_stale"]
    
    # Below return mostly None
    total_value_locked = coin_indicators["total_value_locked"]
    trust_score = coin_indicators["trust_score"]


    fundamental_analysis = ""
    fundamental_analysis += "\nIndicators:\n"
    for key, value in coin_indicators.items():
        fundamental_analysis += f"{key}: {value}\n"

    fundamental_analysis += "\nSignals:\n"
    if block_time_in_minutes < 1:
        fundamental_analysis += f"New block generation time is {block_time_in_minutes} min which is shorter than a minute. UP \n"
    elif block_time_in_minutes< 5:
        fundamental_analysis += f"New block generation time is {block_time_in_minutes} min which is longer than 5 minutes. DOWN \n"
    else:
        fundamental_analysis += f"New block generation time is {block_time_in_minutes} min which is between 1 and 5 minutes. NEUTRAL \n"

    if hashing_algorithm in ["SHA-256", "Ethash", "Blake2b", "SHA-3", "Keccak-256", "RIPEMD-160", "Whirlpool"]:
        fundamental_analysis += f"Used hashing algorithm is {hashing_algorithm} that is accepted as a good algorithm. UP \n"
    elif hashing_algorithm in ["Scrypt", "MD6", "CryptoNight", "MD5", "SHA-1", "RIPEMD-128", "Tiger"]:
        fundamental_analysis += f"Used hashing algorithm is {hashing_algorithm} that is accepted as a bad algorithm. DOWN \n"
    else:
        fundamental_analysis += f"Used hashing algorithm is {hashing_algorithm} not that well known. NEUTRAL \n"

    if links_homepage and any(links_homepage):
        fundamental_analysis += f"There is a website of this coin that is: {links_homepage}. UP \n"
    else:
        fundamental_analysis += "There is no website of this coin. DOWN"

    if whitepaper:
        fundamental_analysis += f"There is a whitepaper of this coin: {whitepaper}. UP \n"
    else:
        fundamental_analysis += "There is not a whitepaper of this coin. DOWN \n"

    if blockchain_site and any(blockchain_site):
        fundamental_analysis += f"There is a blockchain site of this coin: {blockchain_site}. UP \n"
    else:
        fundamental_analysis += "There is not a blockchain site of this coin. DOWN \n"

    if official_forum_url and any(official_forum_url):
        fundamental_analysis += f"There is a official forum website of this coin: {official_forum_url}. UP \n"
    else:
        fundamental_analysis += "There is not a official forum website of this coin. DOWN \n"

    social_account_count = sum(1 for value in social_media.values() if value)
    if social_account_count>= 2:
        fundamental_analysis += f"There are multiple social accounts of this coin: {social_media}. UP \n"
    elif social_account_count== 1:
        fundamental_analysis += f"There is a social account of this coin: {social_media}. NEUTRAL \n"
    else:
        fundamental_analysis += "There is not a social account of this coin. DOWN \n"

    if github and any(github):
        fundamental_analysis += f"There is a public Github address of this coin: {github}. UP \n"
    else:
        fundamental_analysis += "There is no public Github address of this coin. DOWN"

    if genesis_date:
        genesis_years = (datetime.now() - datetime.strptime(genesis_date, "%Y-%m-%d")).days // 365
    else:
        genesis_years = None
    
    if genesis_years is None:
        fundamental_analysis += "There is no reported blockchain age. SELL \n"
    elif genesis_years >= 4:
        fundamental_analysis += f"The blockchain age is {genesis_years} years. UP \n"
    else:
        fundamental_analysis += f"The blockchain age is {genesis_years} years. NEUTRAL \n"

    sentiment_ratio = (sentiment_votes_up_percentage /
                       (sentiment_votes_down_percentage or 1))
    if sentiment_ratio > 3:
        fundamental_analysis += f"The sentiment ratio is {sentiment_ratio}. People are mostly positive. UP \n"
    elif sentiment_ratio < 1:
        fundamental_analysis += f"The sentiment ratio is {sentiment_ratio}. People are mostly negative. DOWN \n"
    else:
        fundamental_analysis += f"The sentiment ratio is {sentiment_ratio}. NEUTRAL \n"

    if community_data_twitter_followers > 100000:
        fundamental_analysis += f"There are {community_data_twitter_followers} accounts that are following in Twitter. UP \n"
    if community_data_twitter_followers < 500000:
        fundamental_analysis += f"There are {community_data_twitter_followers} accounts that are following in Twitter. DOWN \n"
    else:
        fundamental_analysis += f"There are {community_data_twitter_followers} accounts that are following in Twitter. NEUTRAL \n"

    if watchlist_portfolio_users > 100000:
        fundamental_analysis += f"There are {watchlist_portfolio_users} coingecko users following this coin. UP \n"
    if watchlist_portfolio_users < 100000:
        fundamental_analysis += f"There are {watchlist_portfolio_users} coingecko users following this coin. DOWN \n"
    else:
        fundamental_analysis += f"There are {watchlist_portfolio_users} coingecko users following this coin. NEUTRAL \n"

    fundamental_analysis += get_developer_data_analysis(developer_data)

    fundamental_analysis += "Coin IS marked as ANOMALY. SELL" if is_anomaly else "Coin is not marked as anomaly. NEUTRAL\n"
    fundamental_analysis += "Coin IS makred as STALE. SELL" if is_stale else "Coin is not marked as stale. NEUTRAL\n"

    return fundamental_analysis

def get_developer_data_analysis(developer_data):
    """Coin's crypto project will be analyzed"""

    # The threshold that indicates the quality of a crypto project github repo values
    thresholds = {
        "forks": 10000,
        "stars": 20000,
        "subscribers": 1000,
        "total_issues": 5000,
        "closed_issues": 5000,
        "pull_requests_merged": 3000,
        "pull_request_contributors": 500,
        "code_additions_deletions_4_weeks": {
            "additions": 5000,
            "deletions": -5000
        },
        "commit_count_4_weeks": 50
    }

    score = 0
    developer_data_signal = ""

    # Calculate score based on thresholds
    if developer_data["forks"] > thresholds["forks"]:
        score += 1
        developer_data_signal += f"The fork count {developer_data['forks']} of the project is larger than the threshold's {thresholds['forks']} \n"
    if developer_data["stars"] > thresholds["stars"]:
        score += 1
        developer_data_signal += f"The star count {developer_data['stars']} of the project is larger than the threshold's {thresholds['stars']} \n"
    if developer_data["subscribers"] > thresholds["subscribers"]:
        score += 1
        developer_data_signal += f"The subscribers count {developer_data['subscribers']} of the project is larger than the threshold's {thresholds['subscribers']} \n"
    if developer_data["total_issues"] > thresholds["total_issues"]:
        score += 1
        developer_data_signal += f"The total issues count {developer_data['total_issues']} of the project is larger than the threshold's {thresholds['total_issues']} \n"
    if developer_data["closed_issues"] > thresholds["closed_issues"]:
        score += 1
        developer_data_signal += f"The closed issues count {developer_data['closed_issues']} of the project is larger than the threshold's {thresholds['closed_issues']} \n"
    if developer_data["pull_requests_merged"] > thresholds["pull_requests_merged"]:
        score += 1
        developer_data_signal += f"The merged pull request count {developer_data['pull_requests_merged']} of the project is larger than the threshold's {thresholds['pull_requests_merged']} \n"
    if developer_data['pull_request_contributors'] > thresholds['pull_request_contributors']:
        score += 1
        developer_data_signal += f"The pull request contributors count {developer_data['pull_request_contributors']} of the project is larger than the threshold's {thresholds['pull_request_contributors']} \n"
    if (developer_data["code_additions_deletions_4_weeks"]["additions"] and 
        developer_data["code_additions_deletions_4_weeks"]["additions"] > thresholds["code_additions_deletions_4_weeks"]["additions"]):
        score += 1
        developer_data_signal += f"The last month's code addition count {developer_data['code_additions_deletions_4_weeks']['additions']} of the project is larger than the threshold's {thresholds['code_additions_deletions_4_weeks']['additions']} \n"
    if (developer_data["code_additions_deletions_4_weeks"]["deletions"] and 
        developer_data["code_additions_deletions_4_weeks"]["deletions"] > thresholds["code_additions_deletions_4_weeks"]["deletions"]):
        score += 1
        developer_data_signal += f"The last month's code deletion count {developer_data['code_additions_deletions_4_weeks']['deletions']} of the project is larger than the threshold's {thresholds['code_additions_deletions_4_weeks']['deletions']} \n"
    if developer_data["commit_count_4_weeks"] > thresholds["commit_count_4_weeks"]:
        score += 1
        developer_data_signal += f"The last month's commit count {developer_data['commit_count_4_weeks']} of the project is larger than the threshold's {thresholds['commit_count_4_weeks']} \n"

    # Determine signal based on score
    if score >= 8:
        developer_data_signal += f"The overall developer score is {score}. UP \n"
    elif score >= 5:
        developer_data_signal += f"The overall developer score is {score}. NEUTRAL \n"
    else:
        developer_data_signal += f"The overall developer score is {score}. DOWN \n"

    return developer_data_signal
    

def _get_llm(model_name:str) -> any:
    "Return one of the LangChain LLM's according to the model_name. OpenAI, AzureOpenAI, llama-3 and Gemini-pro is supported."
    try:
        if model_name == "openai":
            OPENAI_KEY = os.getenv("OPENAI_KEY")
            llm = ChatOpenAI(model="gpt-4o",temperature=0,max_tokens=None,timeout=None,max_retries=2,api_key=OPENAI_KEY)
        elif model_name == "azure_openai":
            AZURE_AD_TOKEN = os.getenv("AZURE_AD_TOKEN")
            AZURE_AD_TOKEN_PROVIDER = os.getenv("AZURE_AD_TOKEN_PROVIDER")
            AZURE_DEPLOYMENT = os.getenv("AZURE_DEPLOYMENT")
            AZURE_ENDPOINT = os.getenv("AZURE_ENDPOINT")
            llm = AzureOpenAI(azure_ad_token=AZURE_AD_TOKEN, azure_ad_token_provider=AZURE_AD_TOKEN_PROVIDER, azure_deployment=AZURE_DEPLOYMENT, azure_endpoint=AZURE_ENDPOINT, model="gpt-3.5-turbo-instruct", temperature=0,)
        elif model_name == "llama3":
            GROQ_API_KEY = os.getenv("GROQ_API_KEY")
            llm = ChatGroq(api_key=GROQ_API_KEY, model_name="llama3-70b-8192", temperature=0.0) #llama-3.1-70b-versatile
        else:
            GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
            llm = ChatGoogleGenerativeAI(google_api_key=GOOGLE_API_KEY, model="gemini-1.5-pro", temperature=0)
        return llm
    except Exception as e:
        logging.error(f"Error getting LLM: {e}")
        return None

def get_answer_from_llm(llm: any, signals:str) -> str:
    """LLM analyze the indicators and signals to give a final summarized analysis."""
    
    prompt = """
    You are an experienced crypto analyser that focuses on fundamental analysis.
    You will be provided a comprehensive analysis of multiple indicators and signals.
    Offer guidance on whether the price go up, down, or remain neutral with the help of these signals.
    Your answer tonne should be professional and technical yet easy to understand.
    ONLY ANSWER IN TURKISH.
    
    <Example 1>:
    <HUMAN>:
    Indicators:
    block_time_in_minutes: 0
    hashing_algorithm: Ethash
    categories: ['Galaxy Digital Portfolio', 'Delphi Digital Portfolio', 'GMCI 30 Index', 'GMCI Layer 1 Index', 'Andreessen Horowitz (a16z) Portfolio', 'Alameda Research Portfolio', 'Proof of Stake (PoS)', 'Multicoin Capital Portfolio', 'FTX Holdings', 'Layer 1 (L1)', 'Ethereum Ecosystem', 'Smart Contract Platform']
    description_en: Ethereum is a global, open-source platform for decentralized applications. In other words, the vision is to create a world computer that anyone can build applications in a decentralized manner; while all states and data are distributed and publicly accessible. Ethereum supports smart contracts in which developers can write code in order to program digital value. Examples of decentralized apps (dapps) that are built on Ethereum includes tokens, non-fungible tokens, decentralized finance apps, lending protocol, decentralized exchanges, and much more.
    On Ethereum, all transactions and smart contract executions require a small fee to be paid. This fee is called Gas. In technical terms, Gas refers to the unit of measure on the amount of computational effort required to execute an operation or a smart contract. The more complex the execution operation is, the more gas is required to fulfill that operation. Gas fees are paid entirely in Ether (ETH), which is the native coin of the blockchain. The price of gas can fluctuate from time to time depending on the network demand.
    links_homepage: ['https://www.ethereum.org/', '', '']
    whitepaper: 
    blockchain_site: ['https://etherscan.io/', 'https://ethplorer.io/', 'https://blockchair.com/ethereum', 'https://eth.tokenview.io/', 'https://www.oklink.com/eth', 'https://3xpl.com/ethereum', '', '', '', '']
    official_forum_url: ['', '', '']
    social_media: {'twitter': 'ethereum', 'facebook': '', 'reddit': 'https://www.reddit.com/r/ethereum'}
    github: ['https://github.com/ethereum/go-ethereum', 'https://github.com/ethereum/py-evm', 'https://github.com/ethereum/aleth', 'https://github.com/ethereum/web3.py', 'https://github.com/ethereum/solidity', 'https://github.com/ethereum/sharding', 'https://github.com/ethereum/casper', 'https://github.com/paritytech/parity']
    genesis_date: 2015-07-30
    sentiment_votes_up_percentage: 89.71
    sentiment_votes_down_percentage: 10.29
    watchlist_portfolio_users: 1403235
    total_value_locked: None
    community_data_twitter_followers: 3414261
    developer_data: {'forks': 19618, 'stars': 44422, 'subscribers': 2195, 'total_issues': 7683, 'closed_issues': 7427, 'pull_requests_merged': 5779, 'pull_request_contributors': 906, 'code_additions_deletions_4_weeks': {'additions': 23340, 'deletions': -2460}, 'commit_count_4_weeks': 41, 'last_4_weeks_commit_activity_series': []}
    trust_score: None
    is_anomaly: None
    is_stale: None

    Signals:
    New block generation time is 0 min which is shorter than a minute. UP
    Used hashing algorithm is Ethash that is accepted as a good algorithm. UP
    There is a website of this coin that is: ['https://www.ethereum.org/', '', '']. UP
    There is not a whitepaper of this coin. DOWN
    There is a blockchain site of this coin: ['https://etherscan.io/', 'https://ethplorer.io/', 'https://blockchair.com/ethereum', 'https://eth.tokenview.io/', 'https://www.oklink.com/eth', 'https://3xpl.com/ethereum', '', '', '', '']. UP
    There is not a official forum website of this coin. DOWN
    There are multiple social accounts of this coin: {'twitter': 'ethereum', 'facebook': '', 'reddit': 'https://www.reddit.com/r/ethereum'}. UP
    There is a public Github address of this coin: ['https://github.com/ethereum/go-ethereum', 'https://github.com/ethereum/py-evm', 'https://github.com/ethereum/aleth', 'https://github.com/ethereum/web3.py', 'https://github.com/ethereum/solidity', 'https://github.com/ethereum/sharding', 'https://github.com/ethereum/casper', 'https://github.com/paritytech/parity']. UP
    The blockchain age is 8 years. UP
    The sentiment ratio is 8.718172983479105. People are mostly positive. UP
    There are 3414261 accounts that are following in Twitter. UP
    There are 3414261 accounts that are following in Twitter. NEUTRAL
    There are 1403235 coingecko users following this coin. UP
    There are 1403235 coingecko users following this coin. NEUTRAL
    The fork count 19618 of the project is larger than the threshold's 10000
    The star count 44422 of the project is larger than the threshold's 20000
    The subscribers count 2195 of the project is larger than the threshold's 1000
    The total issues count 7683 of the project is larger than the threshold's 5000
    The closed issues count 7427 of the project is larger than the threshold's 5000
    The merged pull request count 5779 of the project is larger than the threshold's 3000
    The pull request contributors count 906 of the project is larger than the threshold's 500
    The last month's code addition count 23340 of the project is larger than the threshold's 5000
    The last month's code deletion count -2460 of the project is larger than the threshold's -5000
    The overall developer score is 9. UP
    Coin is not marked as anomaly. NEUTRAL
    Coin is not marked as stale. NEUTRAL
    
    <AI>:
    Ethereum (ETH) Genel Bakış

    Ethereum, merkeziyetsiz uygulamalar (dApps) ve akıllı sözleşme yetenekleriyle tanınan önde gelen bir blockchain platformudur.
    Yaygın olarak benimsenmiş olup, kripto para ekosisteminde birçok proje ve tokenin temelini oluşturur.

    Anahtar Göstergeler ve Sinyal Analizi

    Blok Süresi ve Hashing Algoritması
    Blok Süresi: 0 dakika (hızlı işlem işleme anlamına gelir). Sinyal: YUKARI
    Hashing Algoritması: Ethash (iyi bilinen ve güvenli). Sinyal: YUKARI
    Web Varlığı ve Kaynaklar

    Resmi Web Sitesi: Mevcut (https://www.ethereum.org/). Sinyal: YUKARI
    Whitepaper: Mevcut değil. Sinyal: AŞAĞI
    Blockchain Siteleri: Takip için birden fazla site mevcut (Etherscan, Ethplorer, vb.). Sinyal: YUKARI
    Resmi Forum: Mevcut değil. Sinyal: AŞAĞI
    Sosyal Medya ve Topluluk Katılımı

    Sosyal Medya: Twitter ve Reddit'te aktif varlık. Sinyal: YUKARI
    Twitter Takipçileri: 3.414.261. Sinyal: YUKARI
    CoinGecko İzleme Listesi Kullanıcıları: 1.403.235. Sinyal: YUKARI
    
    Geliştirici Aktivitesi
    GitHub Depoları: Yüksek aktiviteye sahip birden fazla aktif depo. Sinyal: YUKARI
    Forklar: 19.618 (yüksek geliştirici ilgisini gösteriyor). Sinyal: YUKARI
    Yıldızlar: 44.422 (güçlü geliştirici desteğini gösteriyor). Sinyal: YUKARI
    Aboneler: 2.195. Sinyal: YUKARI
    Sorunlar ve Pull Requestler: Yüksek sayıda sorun (7.683) ve birleştirilen pull requestler (5.779). Sinyal: YUKARI
    Katkıda Bulunanlar: 906 pull request katkıcısı. Sinyal: YUKARI
    Kod Aktivitesi: Son 4 haftada önemli kod eklemeleri (23.340) ve silmeleri (-2.460). Sinyal: YUKARI
    Genel Geliştirici Puanı: 9/10. Sinyal: YUKARI
    Duyarlılık ve Topluluk Desteği

    Duyarlılık Oyları: %89,71 olumlu. Sinyal: YUKARI
    Güven Puanı: Mevcut değil. Sinyal: NÖTR
    Topluluk Verileri: Güçlü topluluk desteği. Sinyal: YUKARI
    
    Ek Hususlar
    Blockchain Yaşı: 8 yıl (yerleşik ve olgun platform). Sinyal: YUKARI
    Anomali ve Durgunluk: Anomali veya durgun olarak işaretlenmemiştir. Sinyal: NÖTR
    
    Sonuç ve Tavsiye
    Genel Tavsiye: YUKARI
    Ethereum, işlem hızı, hashing algoritması, web varlığı, sosyal medya katılımı, geliştirici aktivitesi ve topluluk desteği gibi birçok boyutta güçlü göstergeler sergiliyor. Resmi bir whitepaper ve forum eksikliğine rağmen, genel olumlu duyarlılık ve güçlü geliştirici aktivitesi, fiyatın artmasını sağlıyor. Platformun olgunluğu ve kripto para ekosistemindeki kritik rolü bu tavsiyeyi daha da destekliyor.
                
    Now it's your turn:
    """
    final_answer = llm.invoke(prompt + signals)
    final_answer = final_answer.content
    return final_answer

def visualize_data(coin_name: str, coin_indicators: dict) -> go.Figure:
    """Visualize signals and indicators."""

    block_time_in_minutes = coin_indicators.get("block_time_in_minutes", 0)
    hashing_algorithm = coin_indicators.get("hashing_algorithm", "N/A")
    categories = ", ".join(coin_indicators.get("categories", []))
    description_en = coin_indicators.get("description_en", "N/A")
    links_homepage = ", ".join(coin_indicators.get("links_homepage", []))
    whitepaper = coin_indicators.get("whitepaper", "N/A")
    blockchain_site = ", ".join(coin_indicators.get("blockchain_site", []))
    official_forum_url = ", ".join(coin_indicators.get("official_forum_url", []))
    social_media = coin_indicators.get("social_media", {})
    github = ", ".join(coin_indicators.get("github", []))
    genesis_date = coin_indicators.get("genesis_date", "N/A")
    sentiment_votes_up_percentage = coin_indicators.get("sentiment_votes_up_percentage", 0)
    sentiment_votes_down_percentage = coin_indicators.get("sentiment_votes_down_percentage", 0)
    watchlist_portfolio_users = coin_indicators.get("watchlist_portfolio_users", 0)
    total_value_locked = coin_indicators.get("total_value_locked", 0)
    community_data_twitter_followers = coin_indicators.get("community_data_twitter_followers", 0)
    developer_data = coin_indicators.get("developer_data", {})
    trust_score = coin_indicators.get("trust_score", 0)
    is_anomaly = coin_indicators.get("is_anomaly", False)
    is_stale = coin_indicators.get("is_stale", False)

    # Create a figure
    fig = go.Figure()

    # Basic Info
    fig.add_trace(go.Indicator(
        mode="number",
        value=block_time_in_minutes if isinstance(block_time_in_minutes, (int, float)) else 0,
        title={'text': "🧱⌛Block Time (Minutes)"},
        domain={'row': 0, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=len(categories.split(',')),
        title={'text': "Categories"},
        domain={'row': 0, 'column': 1}
    ))

    fig.add_trace(go.Indicator(
        mode="number+delta",
        value=sentiment_votes_up_percentage if isinstance(sentiment_votes_up_percentage, (int, float)) else 0,
        delta={'reference': sentiment_votes_down_percentage, 'relative': True, 'position': "top"},
        title={'text': "😊📈 Sentiment Votes Up (%)"},
        domain={'row': 1, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=community_data_twitter_followers if isinstance(community_data_twitter_followers, (int, float)) else 0,
        title={'text': "🐦 Twitter Followers"},
        domain={'row': 1, 'column': 1}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=watchlist_portfolio_users if isinstance(watchlist_portfolio_users, (int, float)) else 0,
        title={'text': "👀📄Watchlist Users"},
        domain={'row': 2, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=len(github.split(',')),
        title={'text': "</>Github Repos"},
        domain={'row': 2, 'column': 1}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=developer_data.get('forks', 0) if isinstance(developer_data.get('forks', 0), (int, float)) else 0,
        title={'text': "👨🏻‍💻🗃️Developer Forks"},
        domain={'row': 3, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=developer_data.get('stars', 0) if isinstance(developer_data.get('stars', 0), (int, float)) else 0,
        title={'text': "👨🏻‍💻⭐Developer Stars"},
        domain={'row': 3, 'column': 1}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=developer_data.get('pull_requests_merged', 0) if isinstance(developer_data.get('pull_requests_merged', 0), (int, float)) else 0,
        title={'text': "🔧🔗Pull Requests Merged"},
        domain={'row': 4, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=developer_data.get('commit_count_4_weeks', 0) if isinstance(developer_data.get('commit_count_4_weeks', 0), (int, float)) else 0,
        title={'text': "🖇Commits Last 4 Weeks"},
        domain={'row': 4, 'column': 1}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=int(developer_data.get('code_additions_deletions_4_weeks', {}).get('additions', 0)) if isinstance(developer_data.get('code_additions_deletions_4_weeks', {}).get('additions', 0), (int, float)) else 0,
        title={'text': "</>➕Code Additions Last 4 Weeks"},
        domain={'row': 5, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=int(developer_data.get('code_additions_deletions_4_weeks', {}).get('deletions', 0)) if isinstance(developer_data.get('code_additions_deletions_4_weeks', {}).get('deletions', 0), (int, float)) else 0,
        title={'text': "</>➖Code Deletions Last 4 Weeks"},
        domain={'row': 5, 'column': 1}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=int(datetime.now().year - int(genesis_date.split('-')[0])) if genesis_date != 'N/A' else 0,
        title={'text': "🧱📆Blockchain Age (Years)"},
        domain={'row': 6, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=1 if is_anomaly else 0,
        title={'text': "🕵️‍♂️Is Anomaly"},
        domain={'row': 6, 'column': 1}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=1 if is_stale else 0,
        title={'text': "🕙Is Stale"},
        domain={'row': 7, 'column': 0}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=1 if trust_score else 0,
        title={'text': "🤝Trust Score"},
        domain={'row': 7, 'column': 1}
    ))

    fig.add_trace(go.Indicator(
        mode="number",
        value=1 if total_value_locked else 0,
        title={'text': "🔐Total Locked Value"},
        domain={'row': 8, 'column': 0}
    ))

    # Table for Descriptions and Links
    fig.add_trace(go.Table(
        header=dict(values=["Metric", "Value"]),
        cells=dict(values=[
            ["Hashing Algorithm", "Categories", "Description", "Homepage Links", "Whitepaper", "Blockchain Sites", "Official Forum URL", "Social Media", "Github Repos"],
            [hashing_algorithm, categories, description_en, links_homepage, whitepaper, blockchain_site, official_forum_url, social_media, github]
        ]),
        domain={'x': [0.5, 1], 'y': [0, 0.20]}
    ))

    # Layout
    fig.update_layout(
        grid={'rows': 10, 'columns': 2, 'pattern': "independent"},
        title=f"{coin_name} Fundamental Analysis"
    )

    return fig

def fundamental_analyser(coin_name:str, visualization:bool=True) -> tuple[str,str]:
    """The main function that should be called when wanted to used.
        Gets coin indicators from api, creates signals from indicators, visualizes data and ask llm to analyze the signals and indicators.
    """
    coin_indicators = get_coin_data(coin_name)
    signals = get_signal(coin_indicators)
    logging.debug(f"[DEBUG] Signal:  {signals} \n")
    fig_html = None
    if visualization:
        fig = visualize_data(coin_name, coin_indicators)
        fig_html = pio.to_html(fig, full_html=True)
    llm = _get_llm(model_name="llama3")
    final_answer = get_answer_from_llm(llm=llm,signals=signals)
    return final_answer, fig_html


if __name__ == "__main__":
    fundamental_analysis = fundamental_analysis = fundamental_analyser("bitcoin")
    print(fundamental_analysis)